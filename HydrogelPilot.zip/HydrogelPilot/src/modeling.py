"""
HydrogelPilot — 建模与交叉验证模块（子智能体 2，正式建模轮）

职责：在干净数据上跑大量模型配置，用严谨的「分组防泄漏 + 两层评估」选出最优模型，
产出可复现的结果表、选定模型（joblib）与建模报告。

方法论（硬要求）：
  1. 分组防泄漏：GroupKFold，分组依据 = (F127DA, PEDOT_CS) 四舍五入到 6 位后拼接字符串。
     同一配方（重复记录）绝不跨训练/测试折。
  2. 两层评估：
     - 第一层「重复分组 CV」：2 个随机化分组种子 × 5 折，仅用于模型搜索/排名，
       **存在选择乐观偏差，不是最终分数**。
     - 第二层「嵌套 CV」：外层 5 折 GroupKFold、内层 3 折 GroupKFold 选模型；
       **外层 OOF R² 才是诚实最终分数**。
  3. 所有变换（标准化、特征工程）都在 Pipeline 内 fold-fitted，不泄漏。

用法：
    py src/modeling.py --data-path <clean_data.csv> --output-dir <outputs_dir>
或作为库调用：
    from modeling import main
    main(data_path, output_dir, seeds=(0, 1), outer_splits=5, inner_splits=3)
"""
from __future__ import annotations

import argparse
import os
import warnings
from collections import Counter

import numpy as np
import pandas as pd
from joblib import dump
from sklearn.base import clone
from sklearn.ensemble import (
    ExtraTreesRegressor,
    GradientBoostingRegressor,
    RandomForestRegressor,
)
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import (
    RBF,
    ConstantKernel,
    Matern,
    WhiteKernel,
)
from sklearn.kernel_ridge import KernelRidge
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import GroupKFold
from sklearn.neighbors import KNeighborsRegressor
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import (
    FunctionTransformer,
    PolynomialFeatures,
    PowerTransformer,
    SplineTransformer,
    StandardScaler,
)
from sklearn.svm import SVR

warnings.filterwarnings("ignore")

# ---------------------------------------------------------------------------
# 全局契约（与数据契约一致）
# ---------------------------------------------------------------------------
FEATURES = ["F127DA", "PEDOT_CS"]
TARGETS = ["E", "Z", "AI"]
GROUP_PRECISION = 6


# ---------------------------------------------------------------------------
# 分组与划分工具
# ---------------------------------------------------------------------------
def make_groups(df: pd.DataFrame, precision: int = GROUP_PRECISION) -> np.ndarray:
    """以 (F127DA, PEDOT_CS) 四舍五入到 precision 位后拼接字符串作为分组键。"""
    keys = []
    for f in FEATURES:
        rounded = np.round(df[f].astype(float), precision).astype(str)
        keys.append(rounded)
    return (keys[0] + "_" + keys[1]).to_numpy()


def randomized_group_kfold(groups, n_splits: int, seed: int):
    """随机化分组 K 折（重复分组 CV 用）。

    同组样本绝不跨折：先把唯一组按给定种子打乱，再按「当前样本数最少」的贪心
    均衡策略把每个组整组放进某一折。返回 (train_idx, test_idx) 迭代器。
    """
    groups = np.asarray(groups)
    uniq = np.unique(groups)
    if len(uniq) < n_splits:
        raise ValueError(f"唯一分组数 {len(uniq)} < 折数 {n_splits}，无法 GroupKFold。")

    rng = np.random.RandomState(seed)
    order = rng.permutation(len(uniq))
    fold_counts = np.zeros(n_splits, dtype=int)
    fold_of_group = {}
    for i in order:
        g = uniq[i]
        k = int(np.argmin(fold_counts))
        fold_of_group[g] = k
        fold_counts[k] += int(np.sum(groups == g))

    folds = np.array([fold_of_group[g] for g in groups])
    for k in range(n_splits):
        yield np.where(folds != k)[0], np.where(folds == k)[0]


# ---------------------------------------------------------------------------
# 模型搜索空间（约 77 个配置，均可扩展）
# ---------------------------------------------------------------------------
def _poly_ridge(name_prefix, degree, alphas):
    return [
        (
            f"{name_prefix}_a{alpha}",
            Pipeline(
                [
                    ("poly", PolynomialFeatures(degree=degree, include_bias=False)),
                    ("ridge", Ridge(alpha=alpha)),
                ]
            ),
        )
        for alpha in alphas
    ]


def build_configs():
    """返回 [(名称, 估计器/Pipeline), ...] 的模型搜索空间。"""
    configs = []

    # 1. 多项式响应面 poly2 / poly3 + Ridge
    configs += _poly_ridge("poly2_ridge", 2, (0.1, 1.0, 10.0))
    configs += _poly_ridge("poly3_ridge", 3, (0.1, 1.0, 10.0))

    # 2. Yeo-Johnson + poly2 + Ridge
    for alpha in (0.1, 1.0, 10.0):
        configs.append(
            (
                f"yeojohnson_poly2_ridge_a{alpha}",
                Pipeline(
                    [
                        ("yj", PowerTransformer(method="yeo-johnson")),
                        ("poly", PolynomialFeatures(degree=2, include_bias=False)),
                        ("ridge", Ridge(alpha=alpha)),
                    ]
                ),
            )
        )

    # 3. log1p + poly2 + Ridge（特征均非负，log1p 安全）
    for alpha in (0.1, 1.0, 10.0):
        configs.append(
            (
                f"log1p_poly2_ridge_a{alpha}",
                Pipeline(
                    [
                        ("log1p", FunctionTransformer(np.log1p, validate=False)),
                        ("poly", PolynomialFeatures(degree=2, include_bias=False)),
                        ("ridge", Ridge(alpha=alpha)),
                    ]
                ),
            )
        )

    # 4. 样条 SplineTransformer + Ridge
    for knots in (3, 4):
        for deg in (2, 3):
            for alpha in (0.1, 1.0, 10.0):
                configs.append(
                    (
                        f"spline_k{knots}_d{deg}_ridge_a{alpha}",
                        Pipeline(
                            [
                                (
                                    "spline",
                                    SplineTransformer(
                                        n_knots=knots, degree=deg, include_bias=False
                                    ),
                                ),
                                ("ridge", Ridge(alpha=alpha)),
                            ]
                        ),
                    )
                )

    # 5. SVR RBF（标准化后）
    for C in (0.3, 1.0, 3.0, 10.0):
        for gamma in ("scale", 0.1, 1.0):
            for eps in (0.01, 0.1):
                configs.append(
                    (
                        f"svr_rbf_C{C}_g{gamma}_e{eps}",
                        Pipeline(
                            [
                                ("scale", StandardScaler()),
                                (
                                    "svr",
                                    SVR(kernel="rbf", C=C, gamma=gamma, epsilon=eps),
                                ),
                            ]
                        ),
                    )
                )

    # 6. ExtraTrees / RandomForest
    for msl in (1, 2, 3, 5):
        configs.append(
            (
                f"extra_trees_msl{msl}",
                ExtraTreesRegressor(
                    n_estimators=100, min_samples_leaf=msl, random_state=0
                ),
            )
        )
    for msl in (1, 2, 3, 5):
        configs.append(
            (
                f"rf_msl{msl}",
                RandomForestRegressor(
                    n_estimators=100, min_samples_leaf=msl, random_state=0
                ),
            )
        )

    # 7. GradientBoosting（huber 损失）
    for md in (1, 2):
        for msl in (2, 5):
            for lr in (0.05, 0.1):
                configs.append(
                    (
                        f"gb_huber_md{md}_msl{msl}_lr{lr}",
                        GradientBoostingRegressor(
                            loss="huber",
                            max_depth=md,
                            min_samples_leaf=msl,
                            learning_rate=lr,
                            n_estimators=100,
                            random_state=0,
                        ),
                    )
                )

    # 8. KNN（标准化后）
    for k in (3, 5, 7, 11):
        for w in ("uniform", "distance"):
            configs.append(
                (
                    f"knn_k{k}_{w}",
                    Pipeline(
                        [
                            ("scale", StandardScaler()),
                            ("knn", KNeighborsRegressor(n_neighbors=k, weights=w)),
                        ]
                    ),
                )
            )

    # 9. 可选：GaussianProcess（RBF / Matern 核）
    for kernel_name, kernel in [
        ("rbf", RBF(length_scale=1.0)),
        ("matern", Matern(length_scale=1.0, nu=1.5)),
    ]:
        configs.append(
            (
                f"gp_{kernel_name}",
                Pipeline(
                    [
                        ("scale", StandardScaler()),
                        (
                            "gp",
                            GaussianProcessRegressor(
                                kernel=ConstantKernel(1.0) * kernel + WhiteKernel(1e-3),
                                normalize_y=True,
                                random_state=0,
                            ),
                        ),
                    ]
                ),
            )
        )

    # 10. 可选：KernelRidge（RBF 核）
    for alpha in (0.1, 1.0, 10.0):
        configs.append(
            (
                f"kr_rbf_a{alpha}",
                Pipeline(
                    [
                        ("scale", StandardScaler()),
                        ("kr", KernelRidge(kernel="rbf", alpha=alpha)),
                    ]
                ),
            )
        )

    return configs


# ---------------------------------------------------------------------------
# 第一层：重复分组 CV（搜索/排名，有选择乐观偏差）
# ---------------------------------------------------------------------------
def repeated_group_cv(X, y, groups, configs, n_splits, seeds):
    """对每个配置跑 seeds × n_splits 次随机化分组 CV，返回排名表。"""
    rows = []
    for name, cfg in configs:
        r2s, maes = [], []
        for seed in seeds:
            for tr, te in randomized_group_kfold(groups, n_splits, seed):
                est = clone(cfg)
                est.fit(X[tr], y[tr])
                pred = est.predict(X[te])
                r2s.append(r2_score(y[te], pred))
                maes.append(mean_absolute_error(y[te], pred))
        rows.append(
            {
                "model": name,
                "cv_r2_mean": float(np.mean(r2s)),
                "cv_r2_std": float(np.std(r2s)),
                "cv_mae_mean": float(np.mean(maes)),
                "n_splits": int(n_splits * len(seeds)),
            }
        )
    rows.sort(key=lambda r: r["cv_r2_mean"], reverse=True)
    return rows


# ---------------------------------------------------------------------------
# 第二层：嵌套 CV（外层 GroupKFold + 内层 GroupKFold 选模型，OOF 为诚实分数）
# ---------------------------------------------------------------------------
def nested_cv(X, y, groups, configs, outer_splits, inner_splits):
    """嵌套 CV：外层 GroupKFold，内层 GroupKFold 选配置，返回 OOF 预测与逐折信息。"""
    oof = np.zeros(len(y))
    fold_info = []

    outer = GroupKFold(n_splits=outer_splits)
    for fold, (tr_idx, te_idx) in enumerate(outer.split(X, y, groups)):
        Xtr, ytr, Xte = X[tr_idx], y[tr_idx], X[te_idx]
        gtr = groups[tr_idx]

        # 内层：3 折 GroupKFold 选模型
        best_name, best_score = None, -np.inf
        inner = GroupKFold(n_splits=inner_splits)
        for name, cfg in configs:
            r2s = []
            for itr, ite in inner.split(Xtr, ytr, gtr):
                est = clone(cfg)
                est.fit(Xtr[itr], ytr[itr])
                r2s.append(r2_score(ytr[ite], est.predict(Xtr[ite])))
            m = float(np.mean(r2s))
            if m > best_score:
                best_score, best_name = m, name

        # 用选中配置在外层训练集上 refit，预测外层测试集
        best_cfg = dict(configs)[best_name]
        est = clone(best_cfg)
        est.fit(Xtr, ytr)
        oof[te_idx] = est.predict(Xte)

        fold_info.append(
            {
                "outer_fold": int(fold),
                "selected_model": best_name,
                "inner_cv_r2_mean": best_score,
                "n_test": int(len(te_idx)),
            }
        )

    return oof, fold_info


# ---------------------------------------------------------------------------
# 主流程
# ---------------------------------------------------------------------------
def main(
    data_path,
    output_dir,
    seeds=(0, 1),
    outer_splits=5,
    inner_splits=3,
    group_precision=GROUP_PRECISION,
):
    """建模主入口。

    参数
    ----
    data_path : str  干净数据 CSV 路径（含列 F127DA, PEDOT_CS, E, Z, AI）。
    output_dir : str  输出目录（写 modeling_results.csv / best_models/ / modeling_report.md）。
    seeds : tuple  重复分组 CV 的随机化种子。
    outer_splits / inner_splits : 嵌套 CV 外/内层折数。
    group_precision : 分组键的四舍五入位数。
    """
    # 1. 读数据
    df = pd.read_csv(data_path)
    X = df[FEATURES].astype(float).to_numpy()
    groups = make_groups(df, precision=group_precision)
    n_groups = len(np.unique(groups))
    print(f"[data] n={len(df)}, 唯一配方组={n_groups}")

    configs = build_configs()
    print(f"[search] 模型配置数={len(configs)}")

    # 2. 逐目标：第一层（搜索）+ 第二层（嵌套 CV）
    layer1_rows = []   # 逐模型 × 逐目标
    layer2_folds = []  # 逐目标 × 外层折
    layer2_oof = []    # 逐目标 诚实 OOF 分数
    oof_preds = {}
    fold_infos = {}

    for target in TARGETS:
        y = df[target].astype(float).to_numpy()
        print(f"\n[target={target}]")

        # 第一层：重复分组 CV（搜索/排名）
        rank = repeated_group_cv(X, y, groups, configs, outer_splits, seeds)
        for r in rank:
            layer1_rows.append({"target": target, **r})
        top3 = rank[:3]
        print(
            "  layer1 top3: "
            + ", ".join(f"{t['model']}={t['cv_r2_mean']:.3f}" for t in top3)
        )

        # 第二层：嵌套 CV
        oof, fold_info = nested_cv(X, y, groups, configs, outer_splits, inner_splits)
        oof_preds[target] = oof
        fold_infos[target] = fold_info
        oof_r2 = float(r2_score(y, oof))
        oof_mae = float(mean_absolute_error(y, oof))
        print(f"  nested OOF R²={oof_r2:.4f}  MAE={oof_mae:.4f}")

        for fi in fold_info:
            layer2_folds.append({"target": target, **fi})
        layer2_oof.append({"target": target, "oof_r2": oof_r2, "oof_mae": oof_mae})

    # 3. 选定最终模型：以嵌套 OOF R² 为准，逐折选中模型的多数票（并列时看第一层均值）
    layer1_rank_map = {}
    for r in layer1_rows:
        layer1_rank_map.setdefault(r["target"], {})[r["model"]] = r["cv_r2_mean"]

    best_models = {}
    os.makedirs(os.path.join(output_dir, "best_models"), exist_ok=True)
    for target in TARGETS:
        y = df[target].astype(float).to_numpy()
        fold_info = fold_infos[target]
        selected = _select_final_model(fold_info, layer1_rank_map.get(target, {}))
        best_models[target] = selected
        # 把最终选定模型名写回 OOF 汇总行，保证 CSV / 报告 / joblib 三处一致
        for o in layer2_oof:
            if o["target"] == target:
                o["final_model"] = selected
        # refit 全量数据并序列化完整 Pipeline
        final_est = clone(dict(configs)[selected])
        final_est.fit(X, y)
        out_path = os.path.join(output_dir, "best_models", f"best_{target}.joblib")
        dump(final_est, out_path)
        print(f"[save] {target} -> {selected} -> {out_path}")

    # 4. 写结果表
    os.makedirs(output_dir, exist_ok=True)
    _write_results_csv(output_dir, layer1_rows, layer2_folds, layer2_oof)

    # 5. 写报告
    report_path = os.path.join(output_dir, "modeling_report.md")
    _write_report(
        report_path,
        df=df,
        n_groups=n_groups,
        n_configs=len(configs),
        seeds=seeds,
        outer_splits=outer_splits,
        inner_splits=inner_splits,
        layer1_rows=layer1_rows,
        layer2_folds=layer2_folds,
        layer2_oof=layer2_oof,
        best_models=best_models,
    )
    print(f"\n[report] {report_path}")
    return {
        "layer1": layer1_rows,
        "layer2_folds": layer2_folds,
        "layer2_oof": layer2_oof,
        "best_models": best_models,
    }


# ---------------------------------------------------------------------------
# 辅助函数
# ---------------------------------------------------------------------------
def _select_final_model(fold_info, layer1_rank_map):
    """多数票选最终模型；并列时取第一层重复分组 CV 均值更高者。"""
    counter = Counter(f["selected_model"] for f in fold_info)
    max_count = max(counter.values())
    tied = [name for name, c in counter.items() if c == max_count]
    if len(tied) == 1:
        return tied[0]
    return max(tied, key=lambda name: layer1_rank_map.get(name, -np.inf))


def _write_results_csv(output_dir, layer1_rows, layer2_folds, layer2_oof):
    path = os.path.join(output_dir, "modeling_results.csv")
    lines = [
        "layer,target,model,outer_fold,cv_r2_mean,cv_r2_std,cv_mae_mean,n_splits,inner_cv_r2_mean,oof_r2,oof_mae,note"
    ]
    for r in layer1_rows:
        lines.append(
            "repeated_group_cv,{target},{model},,{cv_r2_mean:.6f},{cv_r2_std:.6f},"
            "{cv_mae_mean:.6f},{n_splits},,,,search_rank".format(**r)
        )
    for f in layer2_folds:
        lines.append(
            "nested_cv_fold,{target},{selected_model},{outer_fold},,,,,"
            "{inner_cv_r2_mean:.6f},,,per-fold-selection".format(
                target=f["target"],
                selected_model=f["selected_model"],
                outer_fold=f["outer_fold"],
                inner_cv_r2_mean=f["inner_cv_r2_mean"],
            )
        )
    for o in layer2_oof:
        lines.append(
            "nested_cv_oof,{target},{final_model},ALL,,,,,,{oof_r2:.6f},{oof_mae:.6f},honest_final".format(
                target=o["target"],
                final_model=o["final_model"],
                oof_r2=o["oof_r2"],
                oof_mae=o["oof_mae"],
            )
        )
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    print(f"[save] results -> {path}")


def _write_report(
    report_path,
    df,
    n_groups,
    n_configs,
    seeds,
    outer_splits,
    inner_splits,
    layer1_rows,
    layer2_folds,
    layer2_oof,
    best_models,
):
    # 基线（用户第 14 轮，60 条，供对比）
    baseline = {"E": 0.531, "Z": 0.659, "AI": 0.572}

    def top_k(target, k=5):
        rows = [r for r in layer1_rows if r["target"] == target]
        return rows[:k]

    lines = []
    add = lines.append
    add("# HydrogelPilot 建模与交叉验证报告（子智能体 2，正式建模轮）\n")
    add("## 1. 数据口径\n")
    add(f"- 数据文件：`clean_data.csv`，共 **{len(df)} 条**。")
    add(f"- 特征（2）：`F127DA`、`PEDOT_CS`；目标（3）：`E`、`Z`、`AI`（log 尺度原值，直接预测，不做目标变换）。")
    add("- 分组键：`(F127DA, PEDOT_CS)` 四舍五入到 6 位后拼接；本轮 51 条对应 "
        f"**{n_groups} 个唯一配方组**（清洗阶段已把同一配方的重复记录聚合为单行，故本数据内无跨行重复组，"
        "但分组机制仍严格生效，未来若引入含重复配方的数据不会泄漏）。")
    add("- `E_y` 为原始杨氏模量约束列，本轮建模**未使用**（预测目标为 log 尺度 `E`）。\n")

    add("## 2. 方法论\n")
    add("### 2.1 分组防泄漏\n")
    add("- 一律用 **GroupKFold**，分组键为配方字符串；同一配方绝不跨训练/测试折（替代此前错误的普通 KFold）。\n")
    add("### 2.2 两层评估\n")
    add(f"- 第一层「重复分组 CV」：{len(seeds)} 个随机化分组种子 × {outer_splits} 折 = "
        f"{len(seeds) * outer_splits} 次划分，仅用于模型搜索/排名，**存在选择乐观偏差，不是最终分数**。")
    add(f"- 第二层「嵌套 CV」：外层 {outer_splits} 折 GroupKFold、内层 {inner_splits} 折 GroupKFold 选模型；"
        "**外层 OOF R² 才是诚实最终分数**。")
    add("- 所有标准化 / 特征工程（多项式、Yeo-Johnson、log1p、样条）都在 Pipeline 内 fold-fitted，无泄漏。\n")

    add(f"## 3. 搜索空间（{n_configs} 个配置）\n")
    add("- 多项式响应面：poly2/poly3 + Ridge(α=0.1/1/10)（6）")
    add("- Yeo-Johnson + poly2 + Ridge（3）")
    add("- log1p + poly2 + Ridge（3）")
    add("- 样条：SplineTransformer(knots=3/4, deg=2/3) + Ridge（12）")
    add("- SVR RBF（C=0.3/1/3/10 × gamma=scale/0.1/1 × ε=0.01/0.1）（24）")
    add("- ExtraTrees / RandomForest（min_samples_leaf=1/2/3/5，n_estimators=100）（8）")
    add("- GradientBoosting（huber，max_depth=1/2 × min_samples_leaf=2/5 × lr=0.05/0.1）（8）")
    add("- KNN（k=3/5/7/11 × uniform/distance）（8）")
    add("- 可选：GaussianProcess（RBF/Matern 核）（2）、KernelRidge（RBF，α=0.1/1/10）（3）\n")

    add("## 4. 每目标最佳模型与诚实 OOF R²（最终分数）\n")
    add("| 目标 | 最佳模型 | 嵌套 CV OOF R² | OOF MAE | 第14轮基线 R² | 是否 ≥0.75 |")
    add("|---|---|---|---|---|---|")
    for o in layer2_oof:
        t = o["target"]
        b = baseline[t]
        hit = "是" if o["oof_r2"] >= 0.75 else "否"
        add(f"| {t} | `{best_models[t]}` | **{o['oof_r2']:.4f}** | {o['oof_mae']:.4f} | {b:.3f} | {hit} |")
    add("")

    add("## 5. 嵌套 CV 逐折选中模型\n")
    for t in TARGETS:
        add(f"### 目标 {t}\n")
        add("| 外层折 | 选中模型 | 内层 CV R² | 测试样本数 |")
        add("|---|---|---|---|")
        for f in layer2_folds:
            if f["target"] != t:
                continue
            add(f"| {f['outer_fold']} | `{f['selected_model']}` | {f['inner_cv_r2_mean']:.4f} | {f['n_test']} |")
        add("")

    add("## 6. 搜索排名（第一层重复分组 CV，仅供参考，非最终分数）\n")
    for t in TARGETS:
        add(f"### 目标 {t}（Top 5）\n")
        add("| 排名 | 模型 | 重复分组 CV R²（均值±std） | MAE |")
        add("|---|---|---|---|")
        for i, r in enumerate(top_k(t), 1):
            add(f"| {i} | `{r['model']}` | {r['cv_r2_mean']:.4f} ± {r['cv_r2_std']:.4f} | {r['cv_mae_mean']:.4f} |")
        add("")

    add("## 7. 局限与诚实声明\n")
    add("- 样本量仅 51 条、2 个特征，且含多个异质区块（Sobol 全域 / 边界探索 / 外推域 / 峰值定向加密 / 主动学习），"
        "外推域与插值域混在一起，模型泛化受域偏移影响。")
    add("- 嵌套 OOF R² 是「含模型选择」的诚实估计，通常比固定模型的真实泛化略保守。")
    add("- 第一层重复分组 CV 因在全部配置上取最优，存在选择乐观偏差，仅用于排名。")
    add("- 未挑种子刷分：所有随机种子、折数、分组精度均固定并在代码中可复现。")
    add("- 选定模型已 refit 到全部 51 条数据并序列化为 `best_models/best_{target}.joblib`，"
        "但请勿把其训练集表现当作泛化能力；以本表「嵌套 CV OOF R²」为准。\n")

    with open(report_path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines))
    print(f"[save] report -> {report_path}")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="HydrogelPilot 建模与交叉验证")
    parser.add_argument("--data-path", required=True, help="干净数据 CSV 路径")
    parser.add_argument("--output-dir", required=True, help="输出目录")
    parser.add_argument("--seeds", type=int, nargs="*", default=[0, 1])
    parser.add_argument("--outer-splits", type=int, default=5)
    parser.add_argument("--inner-splits", type=int, default=3)
    args = parser.parse_args()

    main(
        data_path=args.data_path,
        output_dir=args.output_dir,
        seeds=tuple(args.seeds),
        outer_splits=args.outer_splits,
        inner_splits=args.inner_splits,
    )
