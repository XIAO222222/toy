# -*- coding: utf-8 -*-
"""
HydrogelPilot 多目标优化子智能体（Agent 3）
================================================

候选配方生成 + 硬约束筛选 + Pareto 多目标探索 + 不确定性标注。

流程
----
1. 读训练数据，取特征 F127DA / PEDOT_CS 的 min/max 作为搜索域。
2. 网格扫描：两特征各取 grid_size 个等间距点（默认 101×101），生成候选配方。
3. 用 3 个已序列化模型（best_E / best_Z / best_AI）预测每个候选的 E、Z、AI（log 尺度），
   并换算物理量 E_y = 10^E。
4. 硬约束筛选：只保留 E_y ∈ [30, 80]（kPa）的候选。
5. Pareto 前沿：在「Z 越小越好、AI 越大越好」两维上求非支配集（numpy 手写支配判定）。
6. 不确定性标注（两个层次）：
   - 全局误差：每个预测值附带模型 CV MAE 作为 ±误差带（log 尺度）。
   - 边界/外推风险：候选落在搜索域 min/max 附近 5% 区间 → extrapolation_risk=True。
   - 硬约束不确定：E_y 预测值离 30 或 80 边界不足 1 个 CV MAE（log 尺度）
     → constraint_uncertain=True。

用法
----
命令行::

    py src/optimization.py --data_path <csv> --model_dir <dir> --output_dir <dir>

模块导入::

    from optimization import main
    main(data_path, model_dir, output_dir)

依赖：numpy / pandas / scikit-learn / joblib（无需 scipy）。
"""

import argparse
import os

import joblib
import numpy as np
import pandas as pd

FEATURES = ['F127DA', 'PEDOT_CS']
TARGETS = ['E', 'Z', 'AI']

# 模型 CV MAE（log 尺度，来自建模轮，作为全局不确定性基准）
DEFAULT_CV_MAE = {'E': 0.0675, 'Z': 0.1043, 'AI': 0.298}

# 硬约束：E_y = 10^E ∈ [E_Y_LOWER, E_Y_UPPER]（kPa，物理尺度）
E_Y_LOWER = 30.0
E_Y_UPPER = 80.0

# 边界/外推风险：搜索域 min/max 附近 EDGE_FRAC（默认 5%）区间
EDGE_FRAC = 0.05


def pareto_mask(z, ai):
    """在「Z 最小化、AI 最大化」两目标下返回非支配点的布尔 mask。

    支配定义：点 j 支配点 i，当且仅当
        z[j] <= z[i] 且 ai[j] >= ai[i] 且 (z[j] < z[i] 或 ai[j] > ai[i])
    返回所有「不被任何其他点支配」的点（非支配集 = Pareto 前沿）。
    """
    z = np.asarray(z, dtype=float)
    ai = np.asarray(ai, dtype=float)
    n = len(z)
    keep = np.ones(n, dtype=bool)
    for i in range(n):
        if not keep[i]:
            continue
        dominated_by = (z <= z[i]) & (ai >= ai[i]) & ((z < z[i]) | (ai > ai[i]))
        if np.any(dominated_by):
            keep[i] = False
    return keep


def edge_risk_mask(x, lo, hi, frac=EDGE_FRAC):
    """搜索域边缘（min/max 附近 frac 区间）→ 外推风险。"""
    span = hi - lo
    return (x <= lo + frac * span) | (x >= hi - frac * span)


def constraint_uncertain_mask(log_E, cv_mae_E):
    """E_y 预测值离 30 或 80 边界不足 1 个 CV MAE（log 尺度）→ 硬约束不确定。"""
    lo_log = np.log10(E_Y_LOWER)
    hi_log = np.log10(E_Y_UPPER)
    return (log_E - lo_log < cv_mae_E) | (hi_log - log_E < cv_mae_E)


def compute_candidates(data_path, model_dir, grid_size=101, cv_mae=None):
    """执行候选生成 + 筛选 + Pareto + 标注，返回结果字典。"""
    cv_mae = dict(DEFAULT_CV_MAE) if cv_mae is None else dict(cv_mae)

    # 1. 搜索域
    df = pd.read_csv(data_path)
    lo = {f: float(df[f].min()) for f in FEATURES}
    hi = {f: float(df[f].max()) for f in FEATURES}

    # 2. 网格
    grid = {f: np.linspace(lo[f], hi[f], grid_size) for f in FEATURES}
    g1, g2 = np.meshgrid(grid[FEATURES[0]], grid[FEATURES[1]], indexing='ij')
    X = np.column_stack([g1.ravel(), g2.ravel()])
    n_total = X.shape[0]

    # 3. 预测（log 尺度）
    preds = {}
    for t in TARGETS:
        model = joblib.load(os.path.join(model_dir, 'best_%s.joblib' % t))
        preds[t] = model.predict(X)
    E = preds['E']
    Z = preds['Z']
    AI = preds['AI']
    E_y = np.power(10.0, E)

    # 4. 硬约束筛选
    valid = (E_y >= E_Y_LOWER) & (E_y <= E_Y_UPPER)

    # 5. Pareto（仅在通过硬约束的子集上）
    idx = np.where(valid)[0]
    pf = pareto_mask(Z[idx], AI[idx])
    is_pareto = np.zeros(n_total, dtype=bool)
    is_pareto[idx[pf]] = True

    # 6. 不确定性标注
    ext = np.zeros(n_total, dtype=bool)
    for f in FEATURES:
        col = FEATURES.index(f)
        ext |= edge_risk_mask(X[:, col], lo[f], hi[f])
    constraint_unc = constraint_uncertain_mask(E, cv_mae['E'])

    out = pd.DataFrame({
        'F127DA': X[:, 0],
        'PEDOT_CS': X[:, 1],
        'E': E,
        'Z': Z,
        'AI': AI,
        'E_y': E_y,
        'is_pareto': is_pareto,
        'extrapolation_risk': ext,
        'constraint_uncertain': constraint_unc,
    })

    candidates = out[valid].reset_index(drop=True)
    pareto_df = candidates[candidates['is_pareto']].reset_index(drop=True)

    return {
        'lo': lo,
        'hi': hi,
        'n_total': n_total,
        'n_valid': int(valid.sum()),
        'candidates': candidates,
        'pareto': pareto_df,
        'cv_mae': cv_mae,
    }


def main(data_path, model_dir, output_dir, grid_size=101, cv_mae=None):
    """主入口：计算并写出 candidates.csv 与 pareto_frontier.csv。"""
    res = compute_candidates(data_path, model_dir, grid_size=grid_size, cv_mae=cv_mae)

    os.makedirs(output_dir, exist_ok=True)
    cand_path = os.path.join(output_dir, 'candidates.csv')
    pareto_path = os.path.join(output_dir, 'pareto_frontier.csv')
    res['candidates'].to_csv(cand_path, index=False)
    res['pareto'].to_csv(pareto_path, index=False)

    lo, hi = res['lo'], res['hi']
    print('搜索域: F127DA [%.4f, %.4f]  PEDOT_CS [%.4f, %.4f]'
          % (lo['F127DA'], hi['F127DA'], lo['PEDOT_CS'], hi['PEDOT_CS']))
    print('网格候选总数: %d' % res['n_total'])
    print('通过硬约束 (E_y ∈ [%g, %g] kPa): %d' % (E_Y_LOWER, E_Y_UPPER, res['n_valid']))
    print('Pareto 前沿点数: %d' % len(res['pareto']))
    print('写出: %s' % cand_path)
    print('写出: %s' % pareto_path)
    print('\n--- Pareto 前沿（按 Z 升序）---')
    print(res['pareto'].sort_values('Z').to_string(index=False))
    return res


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description='HydrogelPilot 多目标优化（Agent 3）')
    ap.add_argument('--data_path', required=True, help='训练数据 clean_data.csv 路径')
    ap.add_argument('--model_dir', required=True, help='best_E/Z/AI.joblib 所在目录')
    ap.add_argument('--output_dir', required=True, help='输出目录')
    ap.add_argument('--grid_size', type=int, default=101, help='每维网格点数（默认 101）')
    args = ap.parse_args()
    main(args.data_path, args.model_dir, args.output_dir, grid_size=args.grid_size)
