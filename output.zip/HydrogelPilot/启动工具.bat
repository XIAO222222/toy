@echo off
cd /d "%~dp0"

rem ============================================================
rem  HydrogelPilot launcher
rem  Auto-creates the virtual env and installs deps on first run,
rem  and auto-rebuilds a broken .venv copied from another machine.
rem ============================================================

rem 1) Locate a Python launcher (python or py)
set "PY=python"
where python >nul 2>nul
if errorlevel 1 (
    where py >nul 2>nul
    if errorlevel 1 (
        echo [ERROR] Python not found. Please install Python 3.11+ and check "Add to PATH", then run this again.
        pause
        exit /b 1
    )
    set "PY=py"
)

rem 2) If .venv exists but is broken (copied from another PC), delete it and rebuild.
if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" --version >nul 2>nul
    if not errorlevel 1 goto run
    echo [INFO] Existing .venv is broken, rebuilding...
    rmdir /s /q ".venv"
)

rem 3) Create the virtual env and install dependencies.
echo [INFO] First run: creating virtual env and installing dependencies (a few minutes)...
%PY% -m venv .venv
if errorlevel 1 (
    echo [ERROR] Failed to create the virtual env. Make sure Python 3.11+ is installed.
    pause
    exit /b 1
)
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (
    echo [ERROR] Failed to install dependencies. Check your network and run this again.
    pause
    exit /b 1
)

:run
echo [INFO] Starting HydrogelPilot... (close this window to stop)
".venv\Scripts\python.exe" -m streamlit run app.py --browser.gatherUsageStats false
pause
