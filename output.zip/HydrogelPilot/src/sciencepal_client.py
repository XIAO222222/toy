# -*- coding: utf-8 -*-
"""SciencePal 客户端：通过 HTTP API 调用自定义智能体（DemoHydrogelPilot）。

支持：
- call_agent(prompt, thread_id) -> (文本回复, thread_id)
  传 thread_id 时在同一会话继续（add_message + start 复用历史），否则新建会话（initiate）。
- trigger_run(prompt, thread_id) -> (run_id, thread_id)
  fire-and-forget：发起运行后立即返回，不读结果流（用于前端触发 SciencePal 后台跑）。
"""
import json
import os
import uuid

import requests

BASE_URL = "https://sciencepal.ai/api"
DEFAULT_AGENT_ID = "131843a6-57a3-4a55-a8b7-d669af166302"  # DemoHydrogelPilot（跑 demo 脚本）
AI_AGENT_ID = "10000000-0000-0000-0000-000000000001"  # General Agent（AI 解读/报告/问答，与跑脚本分开避免抢占算力）

# 项目根目录（本文件在 src/ 下，上一级即项目根）
_BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_SECRETS_PATH = os.path.join(_BASE_DIR, ".streamlit", "secrets.toml")


def load_api_key():
    """读取 SciencePal API key（streamlit secrets 优先，secrets.toml 兜底）。"""
    try:
        import streamlit as st  # noqa: F401

        k = st.secrets.get("SCIENCEPAL_API_KEY")
        if k:
            return str(k).strip()
    except Exception:
        pass

    try:
        if os.path.exists(_SECRETS_PATH):
            with open(_SECRETS_PATH, "r", encoding="utf-8") as fh:
                for line in fh:
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue
                    if "=" in line and not line.lower().startswith("http"):
                        line = line.split("=", 1)[1].strip().strip('"').strip("'")
                    if line.startswith("sp_live"):
                        return line
    except Exception:
        pass

    return None


def _headers(api_key):
    return {"Authorization": "Bearer %s" % api_key}


def _initiate(agent_id, prompt, headers, timeout):
    """发起新会话。返回 (thread_id, run_id) 或 (None, None)。"""
    resp = requests.post(
        BASE_URL + "/agent/initiate",
        headers=headers,
        data={
            "agent_id": agent_id,
            "prompt": prompt,
            "stream": "true",
            "agent_select_type": "manual",
        },
        timeout=timeout,
    )
    resp.raise_for_status()
    run = resp.json()
    return run.get("thread_id"), run.get("agent_run_id")


def _add_message_and_start(thread_id, prompt, headers, timeout):
    """在已有 thread 上追加消息并启动新 run。返回 run_id 或 None。"""
    msg_id = str(uuid.uuid4())
    r1 = requests.post(
        BASE_URL + "/thread/%s/messages" % thread_id,
        headers=headers,
        json={"message_id": msg_id, "content": prompt},
        timeout=timeout,
    )
    r1.raise_for_status()
    r2 = requests.post(
        BASE_URL + "/thread/%s/agent/start" % thread_id,
        headers=headers,
        json={},
        timeout=timeout,
    )
    r2.raise_for_status()
    return r2.json().get("agent_run_id")


def _read_stream(run_id, headers):
    """读 SSE 结果流，返回最终文本回复（stream_status=complete 的那段）。"""
    final_text = ""
    with requests.get(
        BASE_URL + "/agent-run/%s/stream" % run_id,
        headers=headers,
        stream=True,
        timeout=(10, 300),
    ) as s:
        s.raise_for_status()
        for line in s.iter_lines():
            if not line or not line.startswith(b"data:"):
                continue
            payload = line[5:].strip()
            if payload == b"[DONE]":
                break
            try:
                event = json.loads(payload.decode("utf-8"))
            except Exception:
                continue
            if event.get("type") != "assistant":
                continue
            content = event.get("content")
            if not isinstance(content, str):
                continue
            try:
                inner = json.loads(content)
            except Exception:
                continue
            if not isinstance(inner, dict):
                continue
            # stream_status 在 event.metadata（JSON 字符串）里，需再解析一层
            meta = event.get("metadata")
            if isinstance(meta, str):
                try:
                    meta = json.loads(meta)
                except Exception:
                    meta = {}
            if meta.get("stream_status") == "complete":
                text = inner.get("content")
                if isinstance(text, str) and text.strip():
                    final_text = text
    return final_text.strip() or None


def call_agent(prompt, agent_id=None, timeout=180, thread_id=None):
    """调用智能体，返回 (文本回复, thread_id)。失败返回 (None, thread_id)。

    传 thread_id 时在同一会话继续（复用历史）；否则新建会话。
    """
    api_key = load_api_key()
    if not api_key or not prompt:
        return None, thread_id
    agent_id = agent_id or DEFAULT_AGENT_ID
    headers = _headers(api_key)
    try:
        if thread_id:
            run_id = _add_message_and_start(thread_id, prompt, headers, timeout)
        else:
            thread_id, run_id = _initiate(agent_id, prompt, headers, timeout)
        if not run_id:
            return None, thread_id
        return _read_stream(run_id, headers), thread_id
    except Exception:
        return None, thread_id


def trigger_run(prompt, agent_id=None, timeout=30, thread_id=None, files=None):
    """fire-and-forget：发起一次运行后立即返回 (run_id, thread_id)，不读结果流。

    用于「前端触发 SciencePal 后台跑」，本地不等待结果。
    files: 可选 [(文件名, bytes)]，作为附件随 initiate 上传（落到沙箱 /workspace/）。
    带 files 时必须新建会话（add_message 不支持附件）。
    """
    api_key = load_api_key()
    if not api_key or not prompt:
        return None, thread_id
    agent_id = agent_id or DEFAULT_AGENT_ID
    headers = _headers(api_key)
    try:
        if files:
            resp = requests.post(
                BASE_URL + "/agent/initiate",
                headers=headers,
                data={
                    "agent_id": agent_id,
                    "prompt": prompt,
                    "stream": "true",
                    "agent_select_type": "manual",
                },
                files=[("files", (fn, content, "text/csv")) for fn, content in files],
                timeout=timeout,
            )
            resp.raise_for_status()
            run = resp.json()
            return run.get("agent_run_id"), run.get("thread_id")
        if thread_id:
            run_id = _add_message_and_start(thread_id, prompt, headers, timeout)
        else:
            thread_id, run_id = _initiate(agent_id, prompt, headers, timeout)
        return run_id, thread_id
    except Exception:
        return None, thread_id


def agent_available():
    """快速探测 AI 是否可用（验 key 能列 agent）。"""
    api_key = load_api_key()
    if not api_key:
        return False
    try:
        resp = requests.get(
            BASE_URL + "/agent-catalog?usable_only=true",
            headers=_headers(api_key),
            timeout=30,
        )
        return resp.status_code == 200
    except Exception:
        return False
