# -*- coding: utf-8 -*-
"""
HydrogelPilot — 合成数据生成器（Agent 5，竞赛交付）

【重要声明】本脚本生成的是**合成模拟数据，仅用于竞赛方法演示，不代表任何真实实验**。
所有特征与目标均为虚构的脱敏代号，不包含、也不应被解读为任何真实测量结果。

数据契约：
    特征：comp_A ∈ [1, 10]（组分 A 用量，连续）、comp_B ∈ [0, 5]（组分 B 用量，连续）
    目标：杨氏模量、界面阻抗、黏附强度，均为无量纲模拟指标（不代表真实量纲）。

生成机制：
    1. 样本量 160 条；约 13 个 (comp_A, comp_B) 组合被故意重复出现 2~3 次，
       用于演示 GroupKFold 分组防泄漏；其余组合为唯一配方，唯一配方组数 >= 60。
    2. 目标由「明确的非线性函数 + 零均值高斯噪声」生成：
          杨氏模量 = 递增型：随 comp_A 增大而增大，comp_B 仅微弱影响（含二次项）
          界面阻抗 = 递减型：随 comp_A / comp_B 增大而下降（含交互项）
          黏附强度 = 峰值型：在某一 comp_A × comp_B 组合处达到峰值（含二次项 + 交互项）
       三者的「无噪信号」被统一标准化到标准差 = SIGNAL_SCALE（默认 1.0），
       再分别加上偏移，使取值落在合理区间（杨氏模量约束区间 [1.5, 2.0] 位于其分布中部）。
    3. 每个目标叠加零均值高斯噪声，噪声标准差 σ = NOISE_SIGMA（单一可调参数）。
       在信号标准差 = 1.0 的前提下，理论 R² ≈ 1 / (1 + σ²)。
       通过调 σ 可让后续嵌套 CV 的 OOF R² 稳定落在 0.75 ~ 0.85。
    4. 固定随机种子 SEED = 42，全程可复现。

用法：
    py src/synthetic_data.py
输出：
    data/synthetic/synthetic_data.csv（列顺序：comp_A, comp_B, 杨氏模量, 界面阻抗, 黏附强度）
"""
from __future__ import annotations

import os

import numpy as np
import pandas as pd

# ---------------------------------------------------------------------------
# 全局参数（可复现）
# ---------------------------------------------------------------------------
SEED = 42
N_SAMPLES = 160            # 样本量
N_DUP_GROUPS = 13          # 重复配方组数（约 10~15）
DUP_REPS = [2] * 10 + [3] * 3   # 每组重复次数：10 组 ×2 次 + 3 组 ×3 次
PRECISION = 6              # 特征保留小数位（与建模的分组键精度一致）
SIGNAL_SCALE = 1.0         # 无噪信号标准差（标准化后固定为 1.0）
NOISE_SIGMA = 0.50         # 加性高斯噪声标准差 σ（任务⑤据此迭代调优）

# 目标偏移（使各指标落在合理区间；杨氏模量约束区间 [1.5, 2.0] 位于其分布中部）
OFFSET_M1 = 1.75
OFFSET_M2 = 2.00
OFFSET_M3 = 2.00

FEATURES = ["comp_A", "comp_B"]
TARGETS = ["杨氏模量", "界面阻抗", "黏附强度"]

LO_A, HI_A = 1.0, 10.0     # comp_A ∈ [1, 10]
LO_B, HI_B = 0.0, 5.0      # comp_B ∈ [0, 5]

OUT_DIR = os.path.join("data", "synthetic")
OUT_PATH = os.path.join(OUT_DIR, "synthetic_data.csv")


# ---------------------------------------------------------------------------
# 无噪目标形状（物理合理：递增 / 递减 / 峰值）
# ---------------------------------------------------------------------------
def _clean_shapes(A, B):
    """返回三个目标的「无噪形状」数组（未标准化、未加偏移）。

    m1：递增型 —— comp_A 主导，comp_B 微弱影响（含二次项）。
    m2：递减型 —— comp_A / comp_B 越大越低（含交互项）。
    m3：峰值型 —— 在某一 comp_A × comp_B 组合处达到峰值（含二次项 + 交互项）。
    """
    m1 = 0.30 * A + 0.05 * B + 0.012 * A * A
    m2 = -(0.20 * A + 0.10 * B + 0.008 * A * B)
    m3 = 0.60 * A + 0.80 * B - 0.05 * A * A - 0.15 * B * B - 0.02 * A * B
    return m1, m2, m3


def _standardize(x):
    """去均值并缩放到标准差 = 1.0（总体标准差，ddof=0）。"""
    x = np.asarray(x, dtype=float)
    return (x - x.mean()) / x.std(ddof=0)


def _unique_points(rng, n):
    """生成 n 个互不重复的 (comp_A, comp_B) 点（四舍五入到 PRECISION 位）。"""
    seen = set()
    pts = []
    while len(pts) < n:
        a = round(float(rng.uniform(LO_A, HI_A)), PRECISION)
        b = round(float(rng.uniform(LO_B, HI_B)), PRECISION)
        key = (a, b)
        if key not in seen:
            seen.add(key)
            pts.append(key)
    return pts


def generate(noise_sigma=NOISE_SIGMA, seed=SEED):
    """生成合成数据，返回 DataFrame（列：comp_A, comp_B, 杨氏模量, 界面阻抗, 黏附强度）。"""
    rng = np.random.default_rng(seed)

    reps = np.array(DUP_REPS)
    rng.shuffle(reps)
    n_dup_samples = int(reps.sum())
    n_unique = N_SAMPLES - n_dup_samples

    # 唯一配方点 + 重复配方点（每个重复组一个基准点）
    unique_pts = _unique_points(rng, n_unique)
    dup_base = _unique_points(rng, N_DUP_GROUPS)

    A_list, B_list = [], []
    for (a, b) in unique_pts:
        A_list.append(a)
        B_list.append(b)
    for (a, b), r in zip(dup_base, reps):
        for _ in range(r):
            A_list.append(a)
            B_list.append(b)

    A = np.asarray(A_list, dtype=float)
    B = np.asarray(B_list, dtype=float)

    # 无噪形状 -> 标准化到标准差 SIGNAL_SCALE -> 加偏移
    m1s, m2s, m3s = _clean_shapes(A, B)
    m1s = _standardize(m1s) * SIGNAL_SCALE + OFFSET_M1
    m2s = _standardize(m2s) * SIGNAL_SCALE + OFFSET_M2
    m3s = _standardize(m3s) * SIGNAL_SCALE + OFFSET_M3

    # 加性高斯噪声
    noise = rng.normal(0.0, noise_sigma, size=(3, len(A)))
    m1 = m1s + noise[0]
    m2 = m2s + noise[1]
    m3 = m3s + noise[2]

    df = pd.DataFrame(
        {
            "comp_A": A,
            "comp_B": B,
            "杨氏模量": m1,
            "界面阻抗": m2,
            "黏附强度": m3,
        }
    )
    return df


def _group_key(a, b):
    return f"{round(a, PRECISION)}_{round(b, PRECISION)}"


def main():
    df = generate(noise_sigma=NOISE_SIGMA, seed=SEED)

    os.makedirs(OUT_DIR, exist_ok=True)
    df.to_csv(OUT_PATH, index=False, float_format="%.10f")

    keys = [_group_key(a, b) for a, b in zip(df["comp_A"], df["comp_B"])]
    n_groups = len(set(keys))
    n_dup_groups = sum(1 for k, c in __import__("collections").Counter(keys).items() if c > 1)

    print("=" * 60)
    print("【重要声明】这是合成模拟数据，仅用于竞赛方法演示，不代表任何真实实验。")
    print("=" * 60)
    print(f"[data] 样本数 = {len(df)}")
    print(f"[data] 唯一配方组数 = {n_groups}（含 {n_dup_groups} 个重复组）")
    print(f"[data] 特征范围: comp_A ∈ [{LO_A}, {HI_A}], comp_B ∈ [{LO_B}, {HI_B}]")
    print(f"[noise] 高斯噪声 σ = {NOISE_SIGMA}（加在标准差 {SIGNAL_SCALE} 的信号上）")
    print(f"[noise] 理论 R^2 ≈ {1.0 / (1.0 + NOISE_SIGMA ** 2):.3f}")
    for t in TARGETS:
        print(f"[target] {t}: mean={df[t].mean():.4f} std={df[t].std(ddof=0):.4f}")
    print(f"[save] {os.path.abspath(OUT_PATH)}")
    return df


if __name__ == "__main__":
    main()
