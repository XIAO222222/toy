# -*- coding: utf-8 -*-
"""
HydrogelPilot — 竞赛版建模与交叉验证（Agent 5，合成数据演示）

【重要声明】本脚本处理的是**合成模拟数据，仅用于竞赛方法演示，不代表任何真实实验**。
特征 comp_A / comp_B、目标杨氏模量 / 界面阻抗 / 黏附强度均为无量纲模拟指标。

职责：在合成数据上跑大量模型配置，用严谨的「分组防泄漏 + 两层评估」选出最优模型，
产出可复现的结果表、选定模型（joblib）与建模报告。

方法论（硬要求）：
  1. 分组防泄漏：GroupKFold，分组依据 = (comp_A, comp_B) 四舍五入到 6 位后拼接字符串。
     同一配方（重复记录）绝不跨训练/测试折。
  2. 两层评估：
     - 第一层「重复分组 CV」：2 个随机化分组种子 × 5 折，仅用于模型搜索/排名，
       **存在选择乐观偏差，不是最终分数**。
     - 第二层「嵌套 CV」：外层 5 折 GroupKFold、内层 3 折 GroupKFold 选模型；
       **外层 OOF R² 才是诚实最终分数**。
  3. 所有变换（标准化、特征工程）都在 Pipeline 内 fold-fitted，不泄漏。

用法：
    py demo_modeling.py --data-path data/synthetic/synthetic_data.csv --output-dir outputs/demo
或作为库调用：
    from demo_modeling import main
    main(data_path, output_dir, seeds=(0, 1), outer_splits=5, inner_splits=3)
"""
from __future__ import annotations

import argparse
import os
import warnings
from collections import Counter

import numpy as np
import pandas as pd
from joblib import dump
from sklearn.base import clone
from sklearn.ensemble import (
    ExtraTreesRegressor,
    GradientBoostingRegressor,
    RandomForestRegressor,
)
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import (
    RBF,
    ConstantKernel,
    Matern,
    WhiteKernel,
)
from sklearn.kernel_ridge import KernelRidge
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import GroupKFold
from sklearn.neighbors import KNeighborsRegressor
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import (
    FunctionTransformer,
    PolynomialFeatures,
    PowerTransformer,
    SplineTransformer,
    StandardScaler,
)
from sklearn.svm import SVR

warnings.filterwarnings("ignore")

# ---------------------------------------------------------------------------
# 全局契约（与合成数据契约一致，脱敏）
# ---------------------------------------------------------------------------
FEATURES = ["comp_A", "comp_B"]
TARGETS = ["杨氏模量", "界面阻抗", "黏附强度"]
GROUP_PRECISION = 6


# ---------------------------------------------------------------------------
# 分组与划分工具
# ---------------------------------------------------------------------------
def make_groups(df: pd.DataFrame, precision: int = GROUP_PRECISION, features=None) -> np.ndarray:
    """以各特征列四舍五入到 precision 位后拼接字符串作为分组键。"""
    features = list(features) if features is not None else FEATURES
    keys = [np.round(df[f].astype(float), precision).astype(str) for f in features]
    out = keys[0]
    for k in keys[1:]:
        out = out + "_" + k
    return out.to_numpy()


def randomized_group_kfold(groups, n_splits: int, seed: int):
    """随机化分组 K 折（重复分组 CV 用）。

    同组样本绝不跨折：先把唯一组按给定种子打乱，再按「当前样本数最少」的贪心
    均衡策略把每个组整组放进某一折。返回 (train_idx, test_idx) 迭代器。
    """
    groups = np.asarray(groups)
    uniq = np.unique(groups)
    if len(uniq) < n_splits:
        raise ValueError(f"唯一分组数 {len(uniq)} < 折数 {n_splits}，无法 GroupKFold。")

    rng = np.random.RandomState(seed)
    order = rng.permutation(len(uniq))
    fold_counts = np.zeros(n_splits, dtype=int)
    fold_of_group = {}
    for i in order:
        g = uniq[i]
        k = int(np.argmin(fold_counts))
        fold_of_group[g] = k
        fold_counts[k] += int(np.sum(groups == g))

    folds = np.array([fold_of_group[g] for g in groups])
    for k in range(n_splits):
        yield np.where(folds != k)[0], np.where(folds == k)[0]


# ---------------------------------------------------------------------------
# 模型搜索空间（约 77 个配置，均可扩展）
# ---------------------------------------------------------------------------
def _poly_ridge(name_prefix, degree, alphas):
    return [
        (
            f"{name_prefix}_a{alpha}",
            Pipeline(
                [
                    ("poly", PolynomialFeatures(degree=degree, include_bias=False)),
                    ("ridge", Ridge(alpha=alpha)),
                ]
            ),
        )
        for alpha in alphas
    ]


def build_configs(fast=False):
    """返回 [(名称, 估计器/Pipeline), ...] 的模型搜索空间。

    fast=True 时跳过 GaussianProcess / KernelRidge 等 O(n^3) 慢模型并减少 SVR 配置数，
    用于在受限算力（如沙箱）下快速跑通演示。
    """
    configs = []

    # 1. 多项式响应面 poly2 / poly3 + Ridge
    configs += _poly_ridge("poly2_ridge", 2, (0.1, 1.0, 10.0))
    configs += _poly_ridge("poly3_ridge", 3, (0.1, 1.0, 10.0))

    # 2. Yeo-Johnson + poly2 + Ridge
    for alpha in (0.1, 1.0, 10.0):
        configs.append(
            (
                f"yeojohnson_poly2_ridge_a{alpha}",
                Pipeline(
                    [
                        ("yj", PowerTransformer(method="yeo-johnson")),
                        ("poly", PolynomialFeatures(degree=2, include_bias=False)),
                        ("ridge", Ridge(alpha=alpha)),
                    ]
                ),
            )
        )

    # 3. log1p + poly2 + Ridge（特征均非负，log1p 安全）
    for alpha in (0.1, 1.0, 10.0):
        configs.append(
            (
                f"log1p_poly2_ridge_a{alpha}",
                Pipeline(
                    [
                        ("log1p", FunctionTransformer(np.log1p, validate=False)),
                        ("poly", PolynomialFeatures(degree=2, include_bias=False)),
                        ("ridge", Ridge(alpha=alpha)),
                    ]
                ),
            )
        )

    # 4. 样条 SplineTransformer + Ridge
    for knots in (3, 4):
        for deg in (2, 3):
            for alpha in (0.1, 1.0, 10.0):
                configs.append(
                    (
                        f"spline_k{knots}_d{deg}_ridge_a{alpha}",
                        Pipeline(
                            [
                                (
                                    "spline",
                                    SplineTransformer(
                                        n_knots=knots, degree=deg, include_bias=False
                                    ),
                                ),
                                ("ridge", Ridge(alpha=alpha)),
                            ]
                        ),
                    )
                )

    # 5. SVR RBF（标准化后）
    if fast:
        svr_grid = [(1.0, "scale"), (3.0, "scale"), (1.0, 0.1), (3.0, 0.1)]
        for C, gamma in svr_grid:
            configs.append(
                (
                    f"svr_rbf_C{C}_g{gamma}_e0.1",
                    Pipeline(
                        [
                            ("scale", StandardScaler()),
                            ("svr", SVR(kernel="rbf", C=C, gamma=gamma, epsilon=0.1)),
                        ]
                    ),
                )
            )
    else:
        for C in (0.3, 1.0, 3.0, 10.0):
            for gamma in ("scale", 0.1, 1.0):
                for eps in (0.01, 0.1):
                    configs.append(
                        (
                            f"svr_rbf_C{C}_g{gamma}_e{eps}",
                            Pipeline(
                                [
                                    ("scale", StandardScaler()),
                                    (
                                        "svr",
                                        SVR(kernel="rbf", C=C, gamma=gamma, epsilon=eps),
                                    ),
                                ]
                            ),
                        )
                    )

    # 6. ExtraTrees / RandomForest
    for msl in (1, 2, 3, 5):
        configs.append(
            (
                f"extra_trees_msl{msl}",
                ExtraTreesRegressor(
                    n_estimators=100, min_samples_leaf=msl, random_state=0
                ),
            )
        )
    for msl in (1, 2, 3, 5):
        configs.append(
            (
                f"rf_msl{msl}",
                RandomForestRegressor(
                    n_estimators=100, min_samples_leaf=msl, random_state=0
                ),
            )
        )

    # 7. GradientBoosting（huber 损失）
    for md in (1, 2):
        for msl in (2, 5):
            for lr in (0.05, 0.1):
                configs.append(
                    (
                        f"gb_huber_md{md}_msl{msl}_lr{lr}",
                        GradientBoostingRegressor(
                            loss="huber",
                            max_depth=md,
                            min_samples_leaf=msl,
                            learning_rate=lr,
                            n_estimators=100,
                            random_state=0,
                        ),
                    )
                )

    # 8. KNN（标准化后）
    for k in (3, 5, 7, 11):
        for w in ("uniform", "distance"):
            configs.append(
                (
                    f"knn_k{k}_{w}",
                    Pipeline(
                        [
                            ("scale", StandardScaler()),
                            ("knn", KNeighborsRegressor(n_neighbors=k, weights=w)),
                        ]
                    ),
                )
            )

    # 9. 可选：GaussianProcess（RBF / Matern 核）—— O(n^3) 慢，fast 模式跳过
    if not fast:
        for kernel_name, kernel in [
            ("rbf", RBF(length_scale=1.0)),
            ("matern", Matern(length_scale=1.0, nu=1.5)),
        ]:
            configs.append(
                (
                    f"gp_{kernel_name}",
                    Pipeline(
                        [
                            ("scale", StandardScaler()),
                            (
                                "gp",
                                GaussianProcessRegressor(
                                    kernel=ConstantKernel(1.0) * kernel + WhiteKernel(1e-3),
                                    normalize_y=True,
                                    random_state=0,
                                ),
                            ),
                        ]
                    ),
                )
            )

    # 10. 可选：KernelRidge（RBF 核）—— O(n^3) 慢，fast 模式跳过
    if not fast:
        for alpha in (0.1, 1.0, 10.0):
            configs.append(
                (
                    f"kr_rbf_a{alpha}",
                    Pipeline(
                        [
                            ("scale", StandardScaler()),
                            ("kr", KernelRidge(kernel="rbf", alpha=alpha)),
                        ]
                    ),
                )
            )

    return configs


# ---------------------------------------------------------------------------
# 第一层：重复分组 CV（搜索/排名，有选择乐观偏差）
# ---------------------------------------------------------------------------
def repeated_group_cv(X, y, groups, configs, n_splits, seeds):
    """对每个配置跑 seeds × n_splits 次随机化分组 CV，返回排名表。"""
    rows = []
    for name, cfg in configs:
        r2s, maes = [], []
        for seed in seeds:
            for tr, te in randomized_group_kfold(groups, n_splits, seed):
                est = clone(cfg)
                est.fit(X[tr], y[tr])
                pred = est.predict(X[te])
                r2s.append(r2_score(y[te], pred))
                maes.append(mean_absolute_error(y[te], pred))
        rows.append(
            {
                "model": name,
                "cv_r2_mean": float(np.mean(r2s)),
                "cv_r2_std": float(np.std(r2s)),
                "cv_mae_mean": float(np.mean(maes)),
                "n_splits": int(n_splits * len(seeds)),
            }
        )
    rows.sort(key=lambda r: r["cv_r2_mean"], reverse=True)
    return rows


# ---------------------------------------------------------------------------
# 第二层：嵌套 CV（外层 GroupKFold + 内层 GroupKFold 选模型，OOF 为诚实分数）
# ---------------------------------------------------------------------------
def nested_cv(X, y, groups, configs, outer_splits, inner_splits):
    """嵌套 CV：外层 GroupKFold，内层 GroupKFold 选配置，返回 OOF 预测与逐折信息。"""
    oof = np.zeros(len(y))
    fold_info = []

    outer = GroupKFold(n_splits=outer_splits)
    for fold, (tr_idx, te_idx) in enumerate(outer.split(X, y, groups)):
        Xtr, ytr, Xte = X[tr_idx], y[tr_idx], X[te_idx]
        gtr = groups[tr_idx]

        # 内层：3 折 GroupKFold 选模型
        best_name, best_score = None, -np.inf
        inner = GroupKFold(n_splits=inner_splits)
        for name, cfg in configs:
            r2s = []
            for itr, ite in inner.split(Xtr, ytr, gtr):
                est = clone(cfg)
                est.fit(Xtr[itr], ytr[itr])
                r2s.append(r2_score(ytr[ite], est.predict(Xtr[ite])))
            m = float(np.mean(r2s))
            if m > best_score:
                best_score, best_name = m, name

        # 用选中配置在外层训练集上 refit，预测外层测试集
        best_cfg = dict(configs)[best_name]
        est = clone(best_cfg)
        est.fit(Xtr, ytr)
        oof[te_idx] = est.predict(Xte)

        fold_info.append(
            {
                "outer_fold": int(fold),
                "selected_model": best_name,
                "inner_cv_r2_mean": best_score,
                "n_test": int(len(te_idx)),
            }
        )

    return oof, fold_info


# ---------------------------------------------------------------------------
# 主流程
# ---------------------------------------------------------------------------
def main(
    data_path,
    output_dir,
    seeds=(0, 1),
    outer_splits=5,
    inner_splits=3,
    group_precision=GROUP_PRECISION,
    features=None,
    targets=None,
    fast=False,
):
    """建模主入口。

    参数
    ----
    data_path : str  合成数据 CSV 路径。
    output_dir : str  输出目录（写 modeling_results.csv / best_models/ / modeling_report.md）。
    seeds : tuple  重复分组 CV 的随机化种子。
    outer_splits / inner_splits : 嵌套 CV 外/内层折数。
    group_precision : 分组键的四舍五入位数。
    features / targets : 可选，特征列 / 目标列；缺省用全局 FEATURES / TARGETS（comp_A/comp_B / 杨氏模量/界面阻抗/黏附强度）。
    """
    features = list(features) if features is not None else FEATURES
    targets = list(targets) if targets is not None else TARGETS

    # 1. 读数据
    df = pd.read_csv(data_path)
    X = df[features].astype(float).to_numpy()
    groups = make_groups(df, precision=group_precision, features=features)
    n_groups = len(np.unique(groups))
    print(f"[data] n={len(df)}, 唯一配方组={n_groups}")

    configs = build_configs(fast=fast)
    print(f"[search] 模型配置数={len(configs)}")

    # 2. 逐目标：第一层（搜索）+ 第二层（嵌套 CV）
    layer1_rows = []   # 逐模型 × 逐目标
    layer2_folds = []  # 逐目标 × 外层折
    layer2_oof = []    # 逐目标 诚实 OOF 分数
    oof_preds = {}
    fold_infos = {}

    for target in targets:
        y = df[target].astype(float).to_numpy()
        print(f"\n[target={target}]")

        # 第一层：重复分组 CV（搜索/排名）
        rank = repeated_group_cv(X, y, groups, configs, outer_splits, seeds)
        for r in rank:
            layer1_rows.append({"target": target, **r})
        top3 = rank[:3]
        print(
            "  layer1 top3: "
            + ", ".join(f"{t['model']}={t['cv_r2_mean']:.3f}" for t in top3)
        )

        # 第二层：嵌套 CV
        oof, fold_info = nested_cv(X, y, groups, configs, outer_splits, inner_splits)
        oof_preds[target] = oof
        fold_infos[target] = fold_info
        oof_r2 = float(r2_score(y, oof))
        oof_mae = float(mean_absolute_error(y, oof))
        print(f"  nested OOF R²={oof_r2:.4f}  MAE={oof_mae:.4f}")

        for fi in fold_info:
            layer2_folds.append({"target": target, **fi})
        layer2_oof.append({"target": target, "oof_r2": oof_r2, "oof_mae": oof_mae})

    # 3. 选定最终模型：以嵌套 OOF R² 为准，逐折选中模型的多数票（并列时看第一层均值）
    layer1_rank_map = {}
    for r in layer1_rows:
        layer1_rank_map.setdefault(r["target"], {})[r["model"]] = r["cv_r2_mean"]

    best_models = {}
    os.makedirs(os.path.join(output_dir, "best_models"), exist_ok=True)
    for target in targets:
        y = df[target].astype(float).to_numpy()
        fold_info = fold_infos[target]
        selected = _select_final_model(fold_info, layer1_rank_map.get(target, {}))
        best_models[target] = selected
        # 把最终选定模型名写回 OOF 汇总行，保证 CSV / 报告 / joblib 三处一致
        for o in layer2_oof:
            if o["target"] == target:
                o["final_model"] = selected
        # refit 全量数据并序列化完整 Pipeline
        final_est = clone(dict(configs)[selected])
        final_est.fit(X, y)
        out_path = os.path.join(output_dir, "best_models", f"best_{target}.joblib")
        dump(final_est, out_path)
        print(f"[save] {target} -> {selected} -> {out_path}")

    # 4. 写结果表
    os.makedirs(output_dir, exist_ok=True)
    _write_results_csv(output_dir, layer1_rows, layer2_folds, layer2_oof)

    # 5. 写报告
    report_path = os.path.join(output_dir, "modeling_report.md")
    _write_report(
        report_path,
        df=df,
        n_groups=n_groups,
        n_configs=len(configs),
        seeds=seeds,
        outer_splits=outer_splits,
        inner_splits=inner_splits,
        layer1_rows=layer1_rows,
        layer2_folds=layer2_folds,
        layer2_oof=layer2_oof,
        best_models=best_models,
        features=features,
        targets=targets,
    )
    print(f"\n[report] {report_path}")
    return {
        "layer1": layer1_rows,
        "layer2_folds": layer2_folds,
        "layer2_oof": layer2_oof,
        "best_models": best_models,
    }


# ---------------------------------------------------------------------------
# 辅助函数
# ---------------------------------------------------------------------------
def _select_final_model(fold_info, layer1_rank_map):
    """多数票选最终模型；并列时取第一层重复分组 CV 均值更高者。"""
    counter = Counter(f["selected_model"] for f in fold_info)
    max_count = max(counter.values())
    tied = [name for name, c in counter.items() if c == max_count]
    if len(tied) == 1:
        return tied[0]
    return max(tied, key=lambda name: layer1_rank_map.get(name, -np.inf))


def _write_results_csv(output_dir, layer1_rows, layer2_folds, layer2_oof):
    path = os.path.join(output_dir, "modeling_results.csv")
    lines = [
        "layer,target,model,outer_fold,cv_r2_mean,cv_r2_std,cv_mae_mean,n_splits,inner_cv_r2_mean,oof_r2,oof_mae,note"
    ]
    for r in layer1_rows:
        lines.append(
            "repeated_group_cv,{target},{model},,{cv_r2_mean:.6f},{cv_r2_std:.6f},"
            "{cv_mae_mean:.6f},{n_splits},,,,search_rank".format(**r)
        )
    for f in layer2_folds:
        lines.append(
            "nested_cv_fold,{target},{selected_model},{outer_fold},,,,,"
            "{inner_cv_r2_mean:.6f},,,per-fold-selection".format(
                target=f["target"],
                selected_model=f["selected_model"],
                outer_fold=f["outer_fold"],
                inner_cv_r2_mean=f["inner_cv_r2_mean"],
            )
        )
    for o in layer2_oof:
        lines.append(
            "nested_cv_oof,{target},{final_model},ALL,,,,,,{oof_r2:.6f},{oof_mae:.6f},honest_final".format(
                target=o["target"],
                final_model=o["final_model"],
                oof_r2=o["oof_r2"],
                oof_mae=o["oof_mae"],
            )
        )
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    print(f"[save] results -> {path}")


def _write_report(
    report_path,
    df,
    n_groups,
    n_configs,
    seeds,
    outer_splits,
    inner_splits,
    layer1_rows,
    layer2_folds,
    layer2_oof,
    best_models,
    features=None,
    targets=None,
):
    features = list(features) if features is not None else FEATURES
    targets = list(targets) if targets is not None else TARGETS

    def top_k(target, k=5):
        rows = [r for r in layer1_rows if r["target"] == target]
        return rows[:k]

    lines = []
    add = lines.append
    add("# HydrogelPilot 竞赛演示 — 软材料配方建模报告（合成数据）\n")
    add("> **【重要声明】本报告所有结果为合成模拟数据，仅用于竞赛方法演示，不代表任何真实实验。**\n")

    add("## 1. 数据口径\n")
    add(f"- 数据文件：`synthetic_data.csv`，共 **{len(df)} 条**。")
    add("- 特征（%d）：%s；目标（%d）：%s（无量纲模拟指标，直接预测）。"
        % (len(features), "、".join("`%s`" % f for f in features),
           len(targets), "、".join("`%s`" % t for t in targets)))
    add("- 分组键：`(%s)` 四舍五入到 6 位后拼接；本数据共 "
        % ", ".join(features)
        + f"**{n_groups} 个唯一配方组**，其中部分配方被故意重复出现 2~3 次，"
        "用于演示 GroupKFold 分组防泄漏（同一配方绝不跨训练/测试折）。")
    add("- 数据为**合成模拟**，由明确的非线性函数 + 高斯噪声生成，用于展示「方法学可达 0.75 以上」的建模能力。\n")

    add("## 2. 方法论\n")
    add("### 2.1 分组防泄漏\n")
    add("- 一律用 **GroupKFold**，分组键为配方字符串；同一配方绝不跨训练/测试折。\n")
    add("### 2.2 两层评估\n")
    add(f"- 第一层「重复分组 CV」：{len(seeds)} 个随机化分组种子 × {outer_splits} 折 = "
        f"{len(seeds) * outer_splits} 次划分，仅用于模型搜索/排名，**存在选择乐观偏差，不是最终分数**。")
    add(f"- 第二层「嵌套 CV」：外层 {outer_splits} 折 GroupKFold、内层 {inner_splits} 折 GroupKFold 选模型；"
        "**外层 OOF R² 才是诚实最终分数**。")
    add("- 所有标准化 / 特征工程（多项式、Yeo-Johnson、log1p、样条）都在 Pipeline 内 fold-fitted，无泄漏。\n")

    add(f"## 3. 搜索空间（{n_configs} 个配置）\n")
    add("- 多项式响应面：poly2/poly3 + Ridge(α=0.1/1/10)（6）")
    add("- Yeo-Johnson + poly2 + Ridge（3）")
    add("- log1p + poly2 + Ridge（3）")
    add("- 样条：SplineTransformer(knots=3/4, deg=2/3) + Ridge（12）")
    add("- SVR RBF（C=0.3/1/3/10 × gamma=scale/0.1/1 × ε=0.01/0.1）（24）")
    add("- ExtraTrees / RandomForest（min_samples_leaf=1/2/3/5，n_estimators=100）（8）")
    add("- GradientBoosting（huber，max_depth=1/2 × min_samples_leaf=2/5 × lr=0.05/0.1）（8）")
    add("- KNN（k=3/5/7/11 × uniform/distance）（8）")
    add("- 可选：GaussianProcess（RBF/Matern 核）（2）、KernelRidge（RBF，α=0.1/1/10）（3）\n")

    add("## 4. 每目标最佳模型与诚实 OOF R²（最终分数）\n")
    add("| 目标 | 最佳模型 | 嵌套 CV OOF R² | OOF MAE |")
    add("|---|---|---|---|")
    for o in layer2_oof:
        t = o["target"]
        add(f"| {t} | `{best_models[t]}` | **{o['oof_r2']:.4f}** | {o['oof_mae']:.4f} |")
    add("")

    add("## 5. 嵌套 CV 逐折选中模型\n")
    for t in targets:
        add(f"### 目标 {t}\n")
        add("| 外层折 | 选中模型 | 内层 CV R² | 测试样本数 |")
        add("|---|---|---|---|")
        for f in layer2_folds:
            if f["target"] != t:
                continue
            add(f"| {f['outer_fold']} | `{f['selected_model']}` | {f['inner_cv_r2_mean']:.4f} | {f['n_test']} |")
        add("")

    add("## 6. 搜索排名（第一层重复分组 CV，仅供参考，非最终分数）\n")
    for t in targets:
        add(f"### 目标 {t}（Top 5）\n")
        add("| 排名 | 模型 | 重复分组 CV R²（均值±std） | MAE |")
        add("|---|---|---|---|")
        for i, r in enumerate(top_k(t), 1):
            add(f"| {i} | `{r['model']}` | {r['cv_r2_mean']:.4f} ± {r['cv_r2_std']:.4f} | {r['cv_mae_mean']:.4f} |")
        add("")

    add("## 7. 局限与诚实声明\n")
    add("- 本数据为合成模拟数据，2 个特征、160 条，目标由平滑非线性函数 + 高斯噪声生成，"
        "因此各模型（尤其多项式响应面）拟合难度较低；这是演示方法学的刻意设计，不代表真实实验难度。")
    add("- 嵌套 OOF R² 是「含模型选择」的诚实估计，通常比固定模型的真实泛化略保守。")
    add("- 第一层重复分组 CV 因在全部配置上取最优，存在选择乐观偏差，仅用于排名。")
    add("- 未挑种子刷分：所有随机种子、折数、分组精度均固定并在代码中可复现。")
    add("- 选定模型已 refit 到全部数据并序列化为 `best_models/best_{target}.joblib`，"
        "但请勿把其训练集表现当作泛化能力；以本表「嵌套 CV OOF R²」为准。\n")

    with open(report_path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines))
    print(f"[save] report -> {report_path}")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="HydrogelPilot 竞赛版建模（合成数据演示）")
    parser.add_argument("--data-path", required=True, help="合成数据 CSV 路径")
    parser.add_argument("--output-dir", required=True, help="输出目录")
    parser.add_argument("--seeds", type=int, nargs="*", default=[0, 1])
    parser.add_argument("--outer-splits", type=int, default=5)
    parser.add_argument("--inner-splits", type=int, default=3)
    parser.add_argument("--features", nargs="*", default=None, help="特征列名（空格分隔），默认 comp_A comp_B")
    parser.add_argument("--targets", nargs="*", default=None, help="目标列名（空格分隔），默认 杨氏模量 界面阻抗 黏附强度")
    parser.add_argument("--fast", action="store_true", help="快速模式：跳过 GP/KernelRidge 等慢模型，减少 SVR 配置，用于沙箱快速跑通")
    args = parser.parse_args()

    main(
        data_path=args.data_path,
        output_dir=args.output_dir,
        seeds=tuple(args.seeds),
        outer_splits=args.outer_splits,
        inner_splits=args.inner_splits,
        features=args.features,
        targets=args.targets,
        fast=args.fast,
    )
