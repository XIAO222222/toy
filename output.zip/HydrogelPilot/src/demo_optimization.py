# -*- coding: utf-8 -*-
"""
HydrogelPilot — 竞赛版多目标优化（Agent 5，合成数据演示）
============================================================

【重要声明】本脚本处理的是**合成模拟数据，仅用于竞赛方法演示，不代表任何真实实验**。
特征 comp_A / comp_B、目标杨氏模量 / 界面阻抗 / 黏附强度均为无量纲模拟指标。

候选配方生成 + 硬约束筛选 + Pareto 多目标探索 + 不确定性标注。

流程
----
1. 读训练数据，取特征 comp_A / comp_B 的 min/max 作为搜索域。
2. 网格扫描：两特征各取 grid_size 个等间距点（默认 101×101），生成候选配方。
3. 用 3 个已序列化模型（best_杨氏模量 / best_界面阻抗 / best_黏附强度）预测每个候选的三个目标。
4. 硬约束筛选：只保留杨氏模量 ∈ [1.5, 2.0] 的候选（无量纲指标，直接比较区间，无单位换算）。
   目标方向：杨氏模量在区间内越低越好、界面阻抗越低越好、黏附强度越高越好。
5. Pareto 前沿：在「界面阻抗最小化、黏附强度最大化」两维上求非支配集（numpy 手写支配判定）。
6. 不确定性标注（两个层次）：
   - 全局误差：每个预测值附带模型 CV MAE 作为 ±误差带（与目标同尺度）。
   - 边界/外推风险：候选落在搜索域 min/max 附近 5% 区间 → extrapolation_risk=True。
   - 硬约束不确定：杨氏模量预测值离 1.5 或 2.0 边界不足 1 个 CV MAE → constraint_uncertain=True。

用法
----
命令行::

    py demo_optimization.py --data_path <csv> --model_dir <dir> --output_dir <dir>

模块导入::

    from demo_optimization import main
    main(data_path, model_dir, output_dir)

依赖：numpy / pandas / scikit-learn / joblib（无需 scipy）。
"""

import argparse
import os

import joblib
import numpy as np
import pandas as pd

FEATURES = ['comp_A', 'comp_B']
TARGETS = ['杨氏模量', '界面阻抗', '黏附强度']

# 模型 CV MAE（来自建模轮嵌套 CV OOF，作为全局不确定性基准，与目标同尺度）
DEFAULT_CV_MAE = {'杨氏模量': 0.4082, '界面阻抗': 0.4327, '黏附强度': 0.4236}

# 硬约束：杨氏模量 ∈ [M1_LOWER, M1_UPPER]（无量纲指标，直接比较，无单位换算）
M1_LOWER = 1.5
M1_UPPER = 2.0

# 边界/外推风险：搜索域 min/max 附近 EDGE_FRAC（默认 5%）区间
EDGE_FRAC = 0.05


def pareto_mask(m2, m3):
    """在「界面阻抗最小化、黏附强度最大化」两目标下返回非支配点的布尔 mask。

    支配定义：点 j 支配点 i，当且仅当
        m2[j] <= m2[i] 且 m3[j] >= m3[i] 且 (m2[j] < m2[i] 或 m3[j] > m3[i])
    返回所有「不被任何其他点支配」的点（非支配集 = Pareto 前沿）。
    """
    m2 = np.asarray(m2, dtype=float)
    m3 = np.asarray(m3, dtype=float)
    n = len(m2)
    keep = np.ones(n, dtype=bool)
    for i in range(n):
        if not keep[i]:
            continue
        dominated_by = (m2 <= m2[i]) & (m3 >= m3[i]) & ((m2 < m2[i]) | (m3 > m3[i]))
        if np.any(dominated_by):
            keep[i] = False
    return keep


def edge_risk_mask(x, lo, hi, frac=EDGE_FRAC):
    """搜索域边缘（min/max 附近 frac 区间）→ 外推风险。"""
    span = hi - lo
    return (x <= lo + frac * span) | (x >= hi - frac * span)


def constraint_uncertain_mask(m1, cv_mae_m1, lower=M1_LOWER, upper=M1_UPPER):
    """约束目标预测值离约束边界不足 1 个 CV MAE → 硬约束不确定。"""
    return (m1 - lower < cv_mae_m1) | (upper - m1 < cv_mae_m1)


def load_cv_mae_from_results(results_csv):
    """从建模结果 CSV 的 nested_cv_oof 层读取各目标的 OOF MAE 作为 CV MAE。

    若文件不存在或格式不符，返回 None（调用方回退到 DEFAULT_CV_MAE）。
    """
    if not results_csv or not os.path.exists(results_csv):
        return None
    try:
        df = pd.read_csv(results_csv)
        oof = df[df["layer"] == "nested_cv_oof"]
        if oof.empty:
            return None
        return {str(row["target"]): float(row["oof_mae"]) for _, row in oof.iterrows()}
    except Exception:
        return None


def compute_candidates(data_path, model_dir, grid_size=101, cv_mae=None,
                       features=None, targets=None, constraint_lower=None, constraint_upper=None,
                       results_csv=None):
    """执行候选生成 + 筛选 + Pareto + 标注，返回结果字典。

    targets 约定：targets[0] 为硬约束目标（落在 [constraint_lower, constraint_upper]），
    targets[1] 为 Pareto 目标 1（最小化），targets[2] 为 Pareto 目标 2（最大化）。
    """
    features = list(features) if features is not None else FEATURES
    targets = list(targets) if targets is not None else TARGETS
    constraint_lower = M1_LOWER if constraint_lower is None else float(constraint_lower)
    constraint_upper = M1_UPPER if constraint_upper is None else float(constraint_upper)
    # CV MAE：显式传入 > 从建模结果 CSV 读取 OOF MAE > 默认值
    if cv_mae is None:
        src = results_csv if results_csv is not None else os.path.join(
            os.path.dirname(model_dir), "modeling_results.csv")
        cv_mae = load_cv_mae_from_results(src)
    cv_mae = dict(DEFAULT_CV_MAE) if cv_mae is None else dict(cv_mae)
    t_c, t_p1, t_p2 = targets[0], targets[1], targets[2]

    # 1. 搜索域
    df = pd.read_csv(data_path)
    lo = {f: float(df[f].min()) for f in features}
    hi = {f: float(df[f].max()) for f in features}

    # 2. 网格
    grid = {f: np.linspace(lo[f], hi[f], grid_size) for f in features}
    g1, g2 = np.meshgrid(grid[features[0]], grid[features[1]], indexing='ij')
    X = np.column_stack([g1.ravel(), g2.ravel()])
    n_total = X.shape[0]

    # 3. 预测
    preds = {}
    for t in targets:
        model = joblib.load(os.path.join(model_dir, 'best_%s.joblib' % t))
        preds[t] = model.predict(X)
    MC = preds[t_c]    # 约束目标
    MP1 = preds[t_p1]  # Pareto 目标 1（最小化）
    MP2 = preds[t_p2]  # Pareto 目标 2（最大化）

    # 4. 硬约束筛选：约束目标 ∈ [lower, upper]
    valid = (MC >= constraint_lower) & (MC <= constraint_upper)

    # 5. Pareto（仅在通过硬约束的子集上，目标1 最小化 / 目标2 最大化）
    idx = np.where(valid)[0]
    pf = pareto_mask(MP1[idx], MP2[idx])
    is_pareto = np.zeros(n_total, dtype=bool)
    is_pareto[idx[pf]] = True

    # 6. 不确定性标注
    ext = np.zeros(n_total, dtype=bool)
    for col, f in enumerate(features):
        ext |= edge_risk_mask(X[:, col], lo[f], hi[f])
    cv_mae_c = cv_mae.get(t_c, 0.4)
    constraint_unc = constraint_uncertain_mask(MC, cv_mae_c, constraint_lower, constraint_upper)

    out = pd.DataFrame({
        features[0]: X[:, 0],
        features[1]: X[:, 1],
        targets[0]: MC,
        targets[1]: MP1,
        targets[2]: MP2,
        'is_pareto': is_pareto,
        'extrapolation_risk': ext,
        'constraint_uncertain': constraint_unc,
    })

    candidates = out[valid].reset_index(drop=True)
    pareto_df = candidates[candidates['is_pareto']].reset_index(drop=True)

    return {
        'lo': lo,
        'hi': hi,
        'n_total': n_total,
        'n_valid': int(valid.sum()),
        'candidates': candidates,
        'pareto': pareto_df,
        'cv_mae': cv_mae,
        'features': features,
        'targets': targets,
        'constraint_lower': constraint_lower,
        'constraint_upper': constraint_upper,
    }


def main(data_path, model_dir, output_dir, grid_size=101, cv_mae=None,
         features=None, targets=None, constraint_lower=None, constraint_upper=None,
         results_csv=None):
    """主入口：计算并写出 candidates.csv 与 pareto_frontier.csv。"""
    res = compute_candidates(data_path, model_dir, grid_size=grid_size, cv_mae=cv_mae,
                             features=features, targets=targets,
                             constraint_lower=constraint_lower, constraint_upper=constraint_upper,
                             results_csv=results_csv)

    os.makedirs(output_dir, exist_ok=True)
    cand_path = os.path.join(output_dir, 'candidates.csv')
    pareto_path = os.path.join(output_dir, 'pareto_frontier.csv')
    res['candidates'].to_csv(cand_path, index=False)
    res['pareto'].to_csv(pareto_path, index=False)

    lo, hi = res['lo'], res['hi']
    feats = res['features']
    t_c, t_p1, t_p2 = res['targets']
    lo_w, hi_w = res['constraint_lower'], res['constraint_upper']
    print('搜索域: %s [%.4f, %.4f]  %s [%.4f, %.4f]'
          % (feats[0], lo[feats[0]], hi[feats[0]], feats[1], lo[feats[1]], hi[feats[1]]))
    print('网格候选总数: %d' % res['n_total'])
    print('通过硬约束 (%s ∈ [%g, %g]): %d' % (t_c, lo_w, hi_w, res['n_valid']))
    print('Pareto 前沿点数: %d' % len(res['pareto']))
    print('写出: %s' % cand_path)
    print('写出: %s' % pareto_path)
    print('\n--- Pareto 前沿（按 %s 升序）---' % t_p1)
    print(res['pareto'].sort_values(t_p1).to_string(index=False))
    return res


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description='HydrogelPilot 竞赛版多目标优化（合成数据演示）')
    ap.add_argument('--data_path', required=True, help='训练数据 CSV 路径')
    ap.add_argument('--model_dir', required=True, help='best_{target}.joblib 所在目录')
    ap.add_argument('--output_dir', required=True, help='输出目录')
    ap.add_argument('--grid_size', type=int, default=101, help='每维网格点数（默认 101）')
    ap.add_argument('--features', nargs='*', default=None, help='特征列名（空格分隔），默认 comp_A comp_B')
    ap.add_argument('--targets', nargs='*', default=None, help='目标列名（空格分隔），默认 杨氏模量 界面阻抗 黏附强度')
    ap.add_argument('--constraint-lower', type=float, default=None, help='约束目标下限，默认 1.5')
    ap.add_argument('--constraint-upper', type=float, default=None, help='约束目标上限，默认 2.0')
    ap.add_argument('--results-csv', default=None, help='建模结果 CSV 路径（自动读取各目标 OOF MAE 作误差带，可选）')
    args = ap.parse_args()
    main(args.data_path, args.model_dir, args.output_dir, grid_size=args.grid_size,
         features=args.features, targets=args.targets,
         constraint_lower=args.constraint_lower, constraint_upper=args.constraint_upper,
         results_csv=args.results_csv)
