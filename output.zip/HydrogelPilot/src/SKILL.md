---
name: new_hydrogel-formulation-demo
description: 软材料配方建模与多目标优化。当用户需要配方数据质检、分组防泄漏交叉验证建模、性能预测、多目标 Pareto 优化或推荐候选配方时使用。默认数据为合成模拟数据，仅用于方法演示。
---

# new_hydrogel-formulation-demo

软材料配方建模与多目标优化演示（合成数据，完全脱敏）。

## 一句话描述

用「分组防泄漏 + 嵌套交叉验证 + 多目标 Pareto 优化」演示从配方数据到推荐候选配方的完整链路。

## 重要声明

> **本技能默认使用的数据为合成模拟数据，仅用于方法演示，不代表真实实验。**
> 默认特征 `comp_A` / `comp_B` 与目标 `杨氏模量` / `界面阻抗` / `黏附强度`，
> 均为无量纲模拟指标，不包含、也不应被解读为任何真实测量结果。

## 字段说明（重要，勿误解为固定字段）

- 脚本的字段名是**参数化**的：`demo_modeling.py` 与 `demo_optimization.py` 均支持用 `--features` / `--targets` 传入任意列名。
- **默认字段仅用于演示数据**：特征 = `comp_A`、`comp_B`；目标 = `杨氏模量`、`界面阻抗`、`黏附强度`。
- 若用户上传**真实数据**，应依据智能体系统提示词中的「字段识别规则」自动识别真实表头，并把识别出的列名通过 `--features` / `--targets` 传入脚本，**不要假设任何固定字段名**。

## 依赖

- numpy
- pandas
- scikit-learn
- matplotlib
- joblib

> SciencePal 沙箱首次运行时若缺少上述包会自动安装。

## 运行步骤

**演示数据（默认字段，无需传参）：**

```bash
# ① 建模：分组防泄漏 + 嵌套交叉验证，产出最优模型与建模报告
# 沙箱算力受限，务必加 --fast（跳过 GP/KernelRidge 等 O(n^3) 慢模型，结果几乎不变）
python demo_modeling.py --data-path data/synthetic/synthetic_data.csv --output-dir outputs/demo --fast

# ② 优化：硬约束筛选 + Pareto 多目标探索 + 不确定性标注
python demo_optimization.py --data_path data/synthetic/synthetic_data.csv --model_dir outputs/demo/best_models --output_dir outputs/demo
```

**真实数据（用 --features / --targets 传入识别出的列名）：**

```bash
python demo_modeling.py --data-path <数据路径> --output-dir outputs/demo --features <特征列...> --targets <目标列...> --fast

python demo_optimization.py --data_path <数据路径> --model_dir outputs/demo/best_models --output_dir outputs/demo \
  --features <特征列...> --targets <目标列...> --constraint-lower <下限> --constraint-upper <上限>
```

## 方法学要点

- **分组防泄漏**：GroupKFold，分组键为配方字符串，同一配方绝不跨训练/测试折。
- **两层评估**：第一层「重复分组 CV」仅用于模型搜索/排名；第二层「嵌套 CV」的外层 OOF R² 才是诚实最终分数。
- **硬约束**：约束目标落在用户指定的区间内（演示数据默认 `杨氏模量 ∈ [1.5, 2.0]`，无量纲直接比较）。
- **多目标**：在「目标1 最小化、目标2 最大化」两维求 Pareto 非支配集（演示数据为 `界面阻抗` 最小化、`黏附强度` 最大化）。

## 输出

- `outputs/demo/modeling_results.csv`：逐模型 × 逐目标的 CV 结果。
- `outputs/demo/modeling_report.md`：建模报告。
- `outputs/demo/best_models/best_{目标}.joblib`：选定模型。
- `outputs/demo/candidates.csv` / `pareto_frontier.csv`：候选与 Pareto 前沿。
- `outputs/demo/model_comparison.png` / `pareto_frontier.png`：可视化。
