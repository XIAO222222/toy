# -*- coding: utf-8 -*-
"""打包竞赛演示技能为 zip，供上传 SciencePal。

用法：  py pack_demo.py
产出：  hydrogel-formulation-demo.zip（与脚本同目录）
"""
import os
import zipfile

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "hydrogel-formulation-demo.zip")

# 源文件 -> zip 内路径（目录结构按 SKILL.md 里的相对路径约定）
FILES = {
    "src/SKILL.md": "new_hydrogel-formulation-demo/SKILL.md",
    "src/synthetic_data.py": "new_hydrogel-formulation-demo/synthetic_data.py",
    "src/demo_modeling.py": "new_hydrogel-formulation-demo/demo_modeling.py",
    "src/demo_optimization.py": "new_hydrogel-formulation-demo/demo_optimization.py",
    "data/synthetic/synthetic_data.csv": "new_hydrogel-formulation-demo/data/synthetic/synthetic_data.csv",
}

with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
    for src, arc in FILES.items():
        p = os.path.join(BASE, src)
        if not os.path.exists(p):
            raise FileNotFoundError("缺少文件: %s" % p)
        z.write(p, arc)

print("打包完成:", OUT)
print("--- zip 内容 ---")
for n in zipfile.ZipFile(OUT).namelist():
    print("  ", n)
