# -*- coding: utf-8 -*-
"""HydrogelPilot — 水凝胶配方智能设计工具（Streamlit 前端）

作品定位：科研工具与应用（AI 增强）。

分步流程（左侧导航 + 状态圆点）：
    ① 数据上传 → ② 字段设置 → ③ 目标设定 → ④ 运行流程 → ⑤ 结果查看 → ⑥ 反向设计 → ⑦ AI 报告

每个环节由本地代码完成核心计算；SciencePal Material Agent 默认自动做解读与报告，
AI 不可用时静默降级（只少解读，不影响本地功能）。

关键设计：
- 后台线程 + fragment 轮询：点击运行后本地计算/AI 解读在后台线程执行，主界面不被阻塞、不置灰。
- 步骤状态：灰点=尚未运行，黄点=正在运行，绿点=已完成。
- 反向设计：输入目标性能（滑块）→ 在原料空间内反推最接近的配方，材料名/指标名完全动态（不写死）。

运行：
    .venv/Scripts/python.exe -m streamlit run app.py
"""
import io
import os
import sys
import threading
from collections import Counter

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import streamlit as st

# 让 app.py 能 import src/ 下的模块
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "src"))

from sciencepal_client import call_agent, trigger_run, agent_available, AI_AGENT_ID  # noqa: E402
from demo_modeling import (  # noqa: E402
    build_configs,
    make_groups,
    repeated_group_cv,
    nested_cv,
)
from demo_optimization import pareto_mask  # noqa: E402
from sklearn.base import clone  # noqa: E402
from sklearn.metrics import r2_score, mean_absolute_error  # noqa: E402

# ---------------------------------------------------------------------------
# 常量与中文字体
# ---------------------------------------------------------------------------
# 无语义代号数据（如内置合成数据）的特征/目标兜底默认约定（通用工具不依赖它）
DEFAULT_FEATURES = ["comp_A", "comp_B"]
DEFAULT_TARGETS = ["杨氏模量", "界面阻抗", "黏附强度"]

# 字段自动识别关键词
FEAT_KW = ["wt%", "%", "含量", "浓度", "组分", "成分", "配比", "比例", "用量", "dosage", "content", "ratio"]
TGT_KW = ["模量", "阻抗", "黏附", "粘附", "剥离", "强度", "溶胀", "拉伸", "导电", "性能", "指标", "modulus", "impedance", "adhesion"]
EXCL_KW = ["编号", "序号", "id", "备注", "日期", "批号", "样本", "区块", "block", "note", "remark", "sample", "no"]

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "Arial Unicode MS"]
plt.rcParams["axes.unicode_minus"] = False

DEMO_DATA = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "data", "synthetic", "synthetic_data.csv"
)

# 流程步骤定义：(key, 显示名, 说明)
STEPS = [
    ("data", "① 数据上传", "上传 CSV 或加载示例数据"),
    ("fields", "② 字段设置", "指定特征列与目标列"),
    ("targets", "③ 目标设定", "硬约束与优化目标"),
    ("run", "④ 运行流程", "一键建模 + 多目标优化"),
    ("results", "⑤ 结果查看", "质检 / 建模 / 优化 / 正向验证"),
    ("reverse", "⑥ 反向设计", "输入性能反推原料配比"),
    ("report", "⑦ AI 报告", "自动生成的科研报告"),
]

# 步骤状态圆点
_DOT = {"pending": "⚪", "running": "🟡", "done": "🟢"}


# 无语义代号 → 直观显示名（仅演示数据 m1/m2/m3；真实数据列名保持原样）
_DISPLAY_NAMES = {"m1": "杨氏模量", "m2": "界面阻抗", "m3": "黏附强度"}


def _col_label(c):
    """返回列的显示名：演示代号映射为直观名，其余直接用列名。"""
    return _DISPLAY_NAMES.get(str(c), str(c))


# ---------------------------------------------------------------------------
# 字段自动识别（通用工具的核心：不依赖固定字段名）
# ---------------------------------------------------------------------------
def _classify_column(name, series):
    """对单列归类：feature / target / exclude / unknown。"""
    cl = str(name).lower()
    if not pd.api.types.is_numeric_dtype(series):
        return "exclude"
    if any(k in cl for k in EXCL_KW):
        return "exclude"
    if series.nunique() <= 1:
        return "exclude"  # 常数列（如恒定的厚度）
    if set(series.dropna().unique()) <= {0, 1}:
        return "exclude"  # 0/1 二值列（如是否分层/是否拉丝）
    if any(k in cl for k in FEAT_KW):
        return "feature"
    if any(k in cl for k in TGT_KW):
        return "target"
    return "unknown"


def detect_columns(df: pd.DataFrame):
    """自动识别特征列、目标列、排除列、未识别列。返回 (features, targets, excluded, unknown)。"""
    features, targets, excluded, unknown = [], [], [], []
    for c in df.columns:
        r = _classify_column(c, df[c])
        if r == "feature":
            features.append(c)
        elif r == "target":
            targets.append(c)
        elif r == "exclude":
            excluded.append(c)
        else:
            unknown.append(c)

    # 兜底：特征和目标都没识别出来（纯无语义代号），按默认约定分配
    if not features and not targets:
        features = unknown[:2]
        targets = unknown[2:5]
        excluded += unknown[5:]
        unknown = []
    # 兜底 2：目标已识别但特征没识别（如演示数据 comp_A/comp_B 属无语义代号）
    elif not features and unknown:
        features = unknown[:2]
        unknown = unknown[2:]
    return features, targets, excluded, unknown


# ---------------------------------------------------------------------------
# 数据质检
# ---------------------------------------------------------------------------
def quality_check(df: pd.DataFrame, features, targets) -> dict:
    """返回质检结果字典（字段由调用方传入，通用）。"""
    report = {"n_rows": len(df), "n_cols": len(df.columns)}

    missing = df.isnull().sum()
    report["missing_total"] = int(missing.sum())
    report["missing_cols"] = {c: int(n) for c, n in missing.items() if n > 0}

    dup = df.duplicated(subset=features, keep=False)
    report["dup_rows"] = int(dup.sum())
    report["dup_groups"] = int(df.loc[dup, features].drop_duplicates().shape[0])

    anomalies = []
    for c in features + targets:
        if c not in df.columns:
            continue
        col = pd.to_numeric(df[c], errors="coerce")
        if col.isnull().any():
            anomalies.append("%s 存在非数值" % _col_label(c))
        if (col < 0).any():
            anomalies.append("%s 存在负值" % _col_label(c))
    report["anomalies"] = anomalies

    report["n_groups"] = int(
        df[features].round(6).astype(str).agg("_".join, axis=1).nunique()
    )
    return report


# ---------------------------------------------------------------------------
# 建模（复用 demo_modeling 的方法学）
# ---------------------------------------------------------------------------
def run_modeling(df: pd.DataFrame, features, targets, outer_splits: int = 5, inner_splits: int = 3, seeds=(0, 1), progress_cb=None) -> dict:
    features = list(features)
    targets = list(targets)
    X = df[features].astype(float).to_numpy()
    groups = make_groups(df, features=features)
    n_groups = len(np.unique(groups))
    # 前端演示提速：fast=True 跳过 GP/KernelRidge，并跳过 SVR / Yeo-Johnson 慢配置；
    # 树模型 fit 相对较慢，仅保留代表性子集。评估方法（GroupKFold 防泄漏 + 嵌套 CV）不变。
    configs = build_configs(fast=True)
    configs = [c for c in configs if not c[0].startswith(("svr_", "yeojohnson_"))]
    skip_trees = {
        "extra_trees_msl2", "extra_trees_msl5",
        "rf_msl2", "rf_msl5",
        "gb_huber_md1_msl5_lr0.05", "gb_huber_md1_msl5_lr0.1",
    }
    configs = [
        c for c in configs
        if c[0] not in skip_trees and not c[0].startswith("gb_huber_md2")
    ]

    outer = max(2, min(outer_splits, n_groups))
    inner = max(2, min(inner_splits, max(2, outer - 1)))

    results = {}
    for i, t in enumerate(targets):
        y = df[t].astype(float).to_numpy()
        rank = repeated_group_cv(X, y, groups, configs, outer, seeds)
        oof, fold_info = nested_cv(X, y, groups, configs, outer, inner)
        oof_r2 = float(r2_score(y, oof))
        oof_mae = float(mean_absolute_error(y, oof))

        cnt = Counter(f["selected_model"] for f in fold_info)
        max_count = max(cnt.values())
        tied = [name for name, c in cnt.items() if c == max_count]
        rank_map = {r["model"]: r["cv_r2_mean"] for r in rank}
        best_name = (max(tied, key=lambda name: rank_map.get(name, -np.inf))
                     if len(tied) > 1 else tied[0])

        model = clone(dict(configs)[best_name])
        model.fit(X, y)

        results[t] = {
            "rank": rank[:8],
            "oof_r2": oof_r2,
            "oof_mae": oof_mae,
            "best_model": best_name,
            "model": model,
            "train_r2": float(r2_score(y, model.predict(X))),
        }
        if progress_cb:
            progress_cb(i + 1, len(targets), t)
    return results


# ---------------------------------------------------------------------------
# 优化（复用 demo_optimization 的 Pareto 逻辑）
# ---------------------------------------------------------------------------
def run_optimization(df: pd.DataFrame, results: dict, features, settings: dict, grid_size: int = 101):
    features = list(features)
    lo = {f: float(df[f].min()) for f in features}
    hi = {f: float(df[f].max()) for f in features}

    ga, gb = np.meshgrid(
        np.linspace(lo[features[0]], hi[features[0]], grid_size),
        np.linspace(lo[features[1]], hi[features[1]], grid_size),
        indexing="ij",
    )
    X = np.column_stack([ga.ravel(), gb.ravel()])

    t_c = settings["constraint_target"]
    t_p1 = settings["pareto_min_target"]
    t_p2 = settings["pareto_max_target"]
    mc = results[t_c]["model"].predict(X)
    mp1 = results[t_p1]["model"].predict(X)
    mp2 = results[t_p2]["model"].predict(X)

    lo_c = settings["constraint_lo"]
    hi_c = settings["constraint_hi"]
    valid = (mc >= lo_c) & (mc <= hi_c)

    idx = np.where(valid)[0]
    pf = pareto_mask(mp1[idx], mp2[idx])
    is_pareto = np.zeros(len(X), dtype=bool)
    is_pareto[idx[pf]] = True

    df_out = pd.DataFrame(
        {
            features[0]: X[:, 0],
            features[1]: X[:, 1],
            t_c: mc,
            t_p1: mp1,
            t_p2: mp2,
            "is_pareto": is_pareto,
        }
    )
    candidates = df_out[valid].reset_index(drop=True)
    pareto = candidates[candidates["is_pareto"]].reset_index(drop=True)
    return candidates, pareto, lo, hi


# ---------------------------------------------------------------------------
# 画图
# ---------------------------------------------------------------------------
def plot_distribution(df: pd.DataFrame, targets):
    targets = list(targets)
    n = len(targets)
    fig, axes = plt.subplots(1, n, figsize=(4.6 * n, 3.6))
    if n == 1:
        axes = [axes]
    for ax, t in zip(axes, targets):
        ax.hist(df[t], bins=20, color="#378ADD", edgecolor="white")
        ax.set_title(_col_label(t) + " 分布", fontsize=12)
        ax.set_xlabel(_col_label(t))
    fig.tight_layout()
    return fig


def plot_pareto(pareto: pd.DataFrame, candidates: pd.DataFrame, t_p1, t_p2):
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.scatter(
        candidates[t_p1], candidates[t_p2],
        s=8, color="#B5D4F4", alpha=0.4, label="全部候选",
    )
    if len(pareto):
        ax.scatter(
            pareto[t_p1], pareto[t_p2],
            s=30, color="#185FA5", label="Pareto 前沿",
        )
    ax.set_xlabel(_col_label(t_p1) + "（越低越好）")
    ax.set_ylabel(_col_label(t_p2) + "（越高越好）")
    ax.legend()
    ax.set_title("Pareto 前沿（%s 最小化 × %s 最大化）" % (_col_label(t_p1), _col_label(t_p2)))
    fig.tight_layout()
    return fig


def plot_model_comparison(results: dict, targets):
    targets = list(targets)
    n = len(targets)
    fig, axes = plt.subplots(1, n, figsize=(5.3 * n, 4))
    if n == 1:
        axes = [axes]
    for ax, t in zip(axes, targets):
        rank = results[t]["rank"][:5]
        names = [r["model"] for r in rank]
        scores = [r["cv_r2_mean"] for r in rank]
        y = list(range(len(names)))[::-1]
        ax.barh(y, scores, color="#378ADD", edgecolor="white")
        ax.set_yticks(y)
        ax.set_yticklabels(names, fontsize=8)
        ax.set_title(_col_label(t) + "：Top 5 模型 CV R²", fontsize=12)
        ax.set_xlabel("重复分组 CV R²")
        if scores:
            ax.set_xlim(0, max(scores) * 1.15)
    fig.tight_layout()
    return fig


# ---------------------------------------------------------------------------
# AI 提示词
# ---------------------------------------------------------------------------
def _report_prompt(df, results, settings, qa, features, targets, opt=None):
    model_sum = "；".join(
        "%s: OOF R²=%.3f(模型 %s)" % (_col_label(t), results[t]["oof_r2"], results[t]["best_model"])
        for t in targets
    )
    opt_txt = ""
    if opt:
        candidates, pareto, lo, hi = opt
        opt_txt = "硬约束(%s∈[%.2f,%.2f])通过 %d 个候选，Pareto 前沿 %d 个点。" % (
            _col_label(settings["constraint_target"]), settings["constraint_lo"],
            settings["constraint_hi"], len(candidates), len(pareto),
        )
    return (
        "请用中文、不超过 200 字、分三点生成一份科研报告摘要：① 数据与模型（%d 条、特征 %s、目标 %s，%s）；"
        "② 主要发现与可靠性（%s）；③ 局限与下一步建议。"
        % (
            qa.get("n_rows", len(df)),
            "/".join(_col_label(f) for f in features),
            "/".join(_col_label(t) for t in targets),
            model_sum,
            opt_txt or "（未运行优化）",
        )
    )


def _sp_trigger_prompt(features, settings):
    """触发 SciencePal 后台同步运行的提示词：用附上的 uploaded_data.csv + 动态字段/约束。

    数据作为附件随 initiate 上传，落到沙箱 /workspace/uploaded_data.csv；这里只引用该路径，
    并传入前端动态识别的特征列、目标列（约束/最小化/最大化）与硬约束区间。
    """
    f0, f1 = features[0], features[1]
    t_c = settings["constraint_target"]
    t_p1 = settings["pareto_min_target"]
    t_p2 = settings["pareto_max_target"]
    lo = settings["constraint_lo"]
    hi = settings["constraint_hi"]
    return (
        "请用我随这条消息附上的文件 uploaded_data.csv 作为数据，运行附加技能里的脚本，"
        "并全程声明这是合成模拟数据：\n"
        "1. python demo_modeling.py --data-path /workspace/uploaded_data.csv "
        "--features %s %s --targets %s %s %s --output-dir outputs/demo\n"
        "2. python demo_optimization.py --data_path /workspace/uploaded_data.csv "
        "--model_dir outputs/demo/best_models --output_dir outputs/demo "
        "--features %s %s --targets %s %s %s "
        "--constraint-lower %s --constraint-upper %s\n"
        "字段已明确给出，请直接运行上述两条命令，不要先询问确认、不要重复运行或做额外分析；"
        "运行完成后报告每个目标的交叉验证 R²、通过硬约束的候选数和 Pareto 前沿点数。"
        % (f0, f1, t_c, t_p1, t_p2, f0, f1, t_c, t_p1, t_p2, lo, hi)
    )


def _qa_interpret_prompt(qa, features, targets):
    """质检环节的 AI 解读提示词（简短，控制在 ~120 字回复）。"""
    return (
        "你是材料配方数据分析助手。下面是数据质检结果，请用不超过 120 字、分点简评："
        "数据质量如何、有无需人工核验的点、是否足以支撑建模。\n"
        "记录数 %d、缺失值 %d、重复配方行 %d、唯一配方组 %d、异常：%s。"
        % (qa.get("n_rows", 0), qa.get("missing_total", 0), qa.get("dup_rows", 0),
           qa.get("n_groups", 0), "；".join(qa.get("anomalies", [])) or "无")
    )


def _model_interpret_prompt(results, targets):
    """建模环节的 AI 解读提示词。"""
    parts = "；".join(
        "%s: 交叉验证 OOF R²=%.3f、最佳模型 %s" % (_col_label(t), results[t]["oof_r2"], results[t]["best_model"])
        for t in targets
    )
    return (
        "你是材料配方数据分析助手。下面是分组防泄漏 + 嵌套交叉验证的建模结果，"
        "请用不超过 150 字、分点简评：各目标可预测性如何、哪个最可信、有无过拟合迹象。\n%s" % parts
    )


def _opt_interpret_prompt(settings, n_cand, n_pareto):
    """优化环节的 AI 解读提示词。"""
    t_c = settings["constraint_target"]
    t_p1 = settings["pareto_min_target"]
    t_p2 = settings["pareto_max_target"]
    return (
        "你是材料配方数据分析助手。下面是多目标优化结果，请用不超过 120 字、分点简评："
        "候选是否贴近约束边界、目标间的权衡关系、以及这些候选的不确定性。\n"
        "硬约束 %s∈[%.2f, %.2f] 通过 %d 个候选，Pareto 前沿 %d 个点（%s 最小化、%s 最大化）。"
        % (_col_label(t_c), settings["constraint_lo"], settings["constraint_hi"], n_cand, n_pareto,
           _col_label(t_p1), _col_label(t_p2))
    )


# ---------------------------------------------------------------------------
# 步骤状态
# ---------------------------------------------------------------------------
def _pipe():
    """返回 pipeline 状态字典（session_state 里的引用，供主线程读、后台线程写）。"""
    p = st.session_state.get("_pipe")
    if not isinstance(p, dict):
        p = {}
        st.session_state["_pipe"] = p
    return p


def _ai_state():
    """返回 AI 助手状态字典（后台线程写，主线程读）。"""
    a = st.session_state.get("_ai")
    if not isinstance(a, dict):
        a = {}
        st.session_state["_ai"] = a
    return a


def _step_status(key):
    """返回某步骤的运行状态：pending / running / done。"""
    ss = st.session_state
    if key == "data":
        return "done" if ss.get("df") is not None else "pending"
    if key == "fields":
        return "done" if (len(ss.get("features", [])) == 2 and len(ss.get("targets", [])) == 3) else "pending"
    if key == "targets":
        s = ss.get("target_settings")
        return "done" if isinstance(s, dict) and s.get("constraint_target") is not None else "pending"
    if key == "run":
        st_ = _pipe().get("status")
        if st_ == "done":
            return "done"
        if st_ == "running":
            return "running"
        return "pending"
    if key == "results":
        st_ = _pipe().get("status")
        if st_ == "done":
            return "done"
        if st_ == "running":
            return "running"
        return "pending"
    if key == "reverse":
        return "done" if (_pipe().get("status") == "done") else "pending"
    if key == "report":
        rep = _pipe().get("report", {})
        if rep.get("status") == "done":
            return "done"
        if rep.get("status") == "running":
            return "running"
        return "pending"
    return "pending"


def _reset_for_new_data():
    """换数据：清空全部 pipeline 与 AI 状态，并开始新会话。"""
    for k in ["_pipe", "_ai", "model_results", "opt_result", "report_text", "qa",
              "pipeline_done", "features", "targets", "target_settings",
              "sp_thread_id", "_field_sig", "_auto_jumped", "_run_stop"]:
        st.session_state.pop(k, None)


def _reset_pipeline():
    """字段/目标变化：清空本地计算与 AI 结果（保留 thread_id 与 AI 助手历史）。"""
    for k in ["_pipe", "model_results", "opt_result", "report_text", "qa",
              "pipeline_done", "_auto_jumped", "_run_stop"]:
        st.session_state.pop(k, None)


# ---------------------------------------------------------------------------
# 后台执行
# ---------------------------------------------------------------------------
def _pipeline_worker(df, features, targets, settings, pipe):
    """后台线程：质检 → 建模 → 优化 → 自动 AI 解读。只操作传入的 dict（不直接写 session_state 顶层）。"""
    try:
        # 0. 触发 SciencePal 后台联动（fire-and-forget，不阻塞）。
        #    把前端上传的数据作为附件传给 SciencePal，让它用同一份数据跑脚本。
        try:
            csv_bytes = df[list(features) + list(targets)].to_csv(index=False).encode("utf-8")
            _, tid = trigger_run(
                _sp_trigger_prompt(features, settings),
                files=[("uploaded_data.csv", csv_bytes)],
            )
            pipe["sp_thread_id"] = tid
        except Exception:
            pass

        # 1. 质检
        pipe["stage"] = "数据质检"
        qa = quality_check(df, features, targets)
        pipe["qa"] = qa
        pipe["progress"] = 8

        # 2. 建模（带进度回调，更新 pipe 供前端轮询）
        def cb(done, total, target):
            pipe["progress"] = 8 + int(done / total * 52)
            pipe["stage"] = "建模：%s（%d/%d）" % (_col_label(target), done, total)

        results = run_modeling(df, features, targets, progress_cb=cb)
        pipe["model_results"] = results
        pipe["progress"] = 60

        # 3. 优化
        pipe["stage"] = "多目标优化"
        candidates, pareto, lo, hi = run_optimization(df, results, features, settings)
        pipe["opt_result"] = (candidates, pareto, lo, hi)
        pipe["progress"] = 100
        pipe["stage"] = "本地计算完成"
        pipe["status"] = "done"

        # 4. 自动 AI 解读（本地计算完成后自动触发，不阻塞前端）。
        #    用 Material Agent（独立智能体）做解读与报告，与跑脚本的 DemoHydrogelPilot 分开，
        #    避免抢占算力；解读线程也独立于触发线程。
        pipe["qa_ai"] = {"status": "running", "text": None}
        pipe["model_ai"] = {"status": "running", "text": None}
        pipe["opt_ai"] = {"status": "running", "text": None}
        pipe["report"] = {"status": "running", "text": None}
        ai_tid = pipe.get("ai_thread_id")

        try:
            text, ai_tid = call_agent(
                _qa_interpret_prompt(qa, features, targets),
                agent_id=AI_AGENT_ID, thread_id=ai_tid, timeout=120,
            )
            pipe["ai_thread_id"] = ai_tid
            pipe["qa_ai"] = {"status": "done" if text else "failed", "text": text}
        except Exception:
            pipe["qa_ai"] = {"status": "failed", "text": None}

        try:
            text, ai_tid = call_agent(
                _model_interpret_prompt(results, targets),
                agent_id=AI_AGENT_ID, thread_id=ai_tid, timeout=120,
            )
            pipe["ai_thread_id"] = ai_tid
            pipe["model_ai"] = {"status": "done" if text else "failed", "text": text}
        except Exception:
            pipe["model_ai"] = {"status": "failed", "text": None}

        try:
            text, ai_tid = call_agent(
                _opt_interpret_prompt(settings, len(candidates), len(pareto)),
                agent_id=AI_AGENT_ID, thread_id=ai_tid, timeout=120,
            )
            pipe["ai_thread_id"] = ai_tid
            pipe["opt_ai"] = {"status": "done" if text else "failed", "text": text}
        except Exception:
            pipe["opt_ai"] = {"status": "failed", "text": None}

        try:
            text, ai_tid = call_agent(
                _report_prompt(df, results, settings, qa, features, targets,
                               opt=(candidates, pareto, lo, hi)),
                agent_id=AI_AGENT_ID, thread_id=ai_tid, timeout=180,
            )
            pipe["ai_thread_id"] = ai_tid
            pipe["report"] = {"status": "done" if text else "failed", "text": text}
        except Exception:
            pipe["report"] = {"status": "failed", "text": None}
    except Exception as e:  # noqa: BLE001
        pipe["status"] = "error"
        pipe["error"] = str(e)


def _ai_worker(q, ai_state, pipe):
    """后台线程：AI 助手问答（General Agent，独立线程，与跑脚本/解读互不干扰）。"""
    try:
        tid = pipe.get("chat_thread_id")
        text, tid = call_agent(q, agent_id=AI_AGENT_ID, thread_id=tid, timeout=180)
        pipe["chat_thread_id"] = tid
        ai_state["status"] = "done"
        ai_state["text"] = text
    except Exception:  # noqa: BLE001
        ai_state["status"] = "done"
        ai_state["text"] = None


def _start_pipeline(df, features, targets, settings):
    """启动后台线程执行 pipeline，并进入「运行中」状态。"""
    pipe = _pipe()
    tid = pipe.get("sp_thread_id")
    pipe.clear()
    if tid:
        pipe["sp_thread_id"] = tid
    pipe.update({
        "status": "running",
        "stage": "准备中",
        "progress": 0,
        "report": {"status": "pending", "text": None},
        "error": None,
    })
    st.session_state["_auto_jumped"] = "no"
    st.session_state["_ai_final_rerun"] = False
    threading.Thread(
        target=_pipeline_worker,
        args=(df.copy(), list(features), list(targets), dict(settings), pipe),
        daemon=True,
    ).start()


# ---------------------------------------------------------------------------
# fragment 轮询（运行中实时刷新，不阻塞主界面）
# ---------------------------------------------------------------------------
@st.fragment(run_every=1.0)
def _run_poll():
    """运行步骤的实时进度轮询。运行结束即触发一次完整 rerun 并停止轮询。"""
    pipe = _pipe()
    status = pipe.get("status")
    if status == "running":
        st.markdown("🟡 **正在运行：%s**" % pipe.get("stage", ""))
        st.progress(min(1.0, max(0.0, pipe.get("progress", 0) / 100.0)))
    else:
        # 运行结束：若尚未自动跳转，跳转到结果页
        if st.session_state.get("_auto_jumped") != "yes":
            st.session_state["_auto_jumped"] = "yes"
            if status == "done":
                st.session_state["_current_step"] = "results"
        st.rerun()


@st.fragment(run_every=1.5)
def _ai_poll():
    """AI 助手回复轮询。回复完成即停止轮询。"""
    ai_state = _ai_state()
    if ai_state.get("status") == "running":
        st.info("🟡 AI 思考中…")
    else:
        st.rerun()


@st.fragment(run_every=2.0)
def _report_poll():
    """AI 报告生成轮询。生成完成即停止轮询。"""
    rep = _pipe().get("report", {})
    if rep.get("status") == "running":
        st.info("🟡 AI 正在生成科研报告…（本地结果已就绪，不受影响）")
    else:
        st.rerun()


@st.fragment(run_every=2.0)
def _interpret_poll():
    """结果页 AI 解读轮询：解读期间持续刷新，全部完成后触发一次完整重绘。"""
    pipe = _pipe()
    busy = any(pipe.get(k, {}).get("status") == "running"
               for k in ("qa_ai", "model_ai", "opt_ai"))
    if busy:
        st.caption("🤖 AI 正在解读各环节结果…")
        st.session_state["_ai_final_rerun"] = False
    elif not st.session_state.get("_ai_final_rerun"):
        st.session_state["_ai_final_rerun"] = True
        st.rerun()


def _ai_block(state):
    """渲染一个 AI 解读块。state = {"status": ..., "text": ...}"""
    if not state:
        return
    st.markdown("🤖 **AI 解读**")
    if state.get("status") == "done" and state.get("text"):
        st.markdown(state["text"])
    elif state.get("status") == "running":
        st.caption("生成中…")
    else:
        st.caption("暂不可用（已降级，本地结果不受影响）")


# ---------------------------------------------------------------------------
# 侧边栏：导航 + AI 助手
# ---------------------------------------------------------------------------
def _ai_available_cached():
    if "_ai_avail" not in st.session_state:
        try:
            st.session_state["_ai_avail"] = agent_available()
        except Exception:  # noqa: BLE001
            st.session_state["_ai_avail"] = False
    return st.session_state["_ai_avail"]


def _nav():
    with st.sidebar:
        st.title("HydrogelPilot")
        st.caption("水凝胶配方智能设计工具 · 通用")
        st.divider()
        st.markdown("**流程步骤**")
        current = st.session_state.get("_current_step", "data")
        for key, name, _desc in STEPS:
            dot = _DOT[_step_status(key)]
            # 所有步骤统一用 button 渲染（同宽同高、间隙均匀、对齐），
            # 当前步骤用 primary 高亮，非当前步骤为普通按钮。
            if key == current:
                st.button("%s　%s" % (dot, name), key="navbtn_%s" % key,
                          type="primary", width="stretch")
            else:
                if st.button("%s　%s" % (dot, name), key="navbtn_%s" % key,
                             width="stretch"):
                    st.session_state["_current_step"] = key
                    st.rerun()

        st.divider()
        st.markdown("**AI 助手**：" + ("可用" if _ai_available_cached() else "降级"))

        with st.form("ai_form", clear_on_submit=True):
            q = st.text_input("问 AI 助手", key="ai_q_input", placeholder="例如：为什么这个候选更好？")
            submitted = st.form_submit_button("发送", width="stretch")

        if submitted and q:
            ai_state = _ai_state()
            ai_state["status"] = "running"
            ai_state["text"] = None
            threading.Thread(
                target=_ai_worker, args=(q, ai_state, _pipe()), daemon=True
            ).start()

        ai_state = _ai_state()
        if ai_state.get("status") == "running":
            _ai_poll()
        elif ai_state.get("status") == "done":
            text = ai_state.get("text")
            if text:
                with st.expander("AI 回复", expanded=True):
                    st.markdown(text)
            else:
                st.caption("AI 暂不可用（已降级）。")

        st.caption("真实数据仅在本地处理，绝不外传")


# ---------------------------------------------------------------------------
# 各步骤渲染
# ---------------------------------------------------------------------------
def _render_data_step():
    st.header("① 数据上传")
    c1, c2 = st.columns([3, 1], vertical_alignment="center")
    with c1:
        uploaded = st.file_uploader("上传配方数据（CSV 或 Excel）", type=["csv", "xlsx", "xls"], key="uploader")
    with c2:
        use_demo = st.button("加载内置示例数据", key="demo_btn")

    df = None
    new_data = False

    if uploaded is not None:
        # 用文件标识判断是否真的换了文件，避免每次 rerun 都误判为新数据（修复结果丢失）
        fid = getattr(uploaded, "file_id", None) or (uploaded.name + "|" + str(uploaded.size))
        ext = uploaded.name.lower().rsplit(".", 1)[-1] if "." in uploaded.name else ""
        if ext in ("xlsx", "xls"):
            # Excel：先列 sheet 让用户选，再读所选 sheet
            try:
                raw = uploaded.getvalue()
                sheets = pd.ExcelFile(io.BytesIO(raw)).sheet_names
            except Exception as e:  # noqa: BLE001
                st.error("读取 Excel 失败：%s" % e)
                sheets = []
            if sheets:
                sheet = st.selectbox("选择工作表", sheets, key="sheet_sel")
                fid2 = fid + "|" + sheet
                if st.session_state.get("_uploaded_fid") != fid2:
                    try:
                        df = pd.read_excel(io.BytesIO(raw), sheet_name=sheet)
                        st.session_state["_uploaded_fid"] = fid2
                        new_data = True
                    except Exception as e:  # noqa: BLE001
                        st.error("读取工作表失败：%s" % e)
                else:
                    df = st.session_state.get("df")
        else:
            if st.session_state.get("_uploaded_fid") != fid:
                try:
                    df = pd.read_csv(uploaded)
                    st.session_state["_uploaded_fid"] = fid
                    new_data = True
                except Exception as e:  # noqa: BLE001
                    st.error("读取 CSV 失败：%s" % e)
            else:
                df = st.session_state.get("df")
    elif use_demo:
        df = pd.read_csv(DEMO_DATA)
        st.session_state["_uploaded_fid"] = "demo"
        new_data = True
    else:
        df = st.session_state.get("df")

    if new_data and df is not None:
        _reset_for_new_data()
        st.session_state["df"] = df
        st.session_state["_current_step"] = "fields"
        st.rerun()

    if df is None:
        st.info("请上传 CSV / Excel，或加载内置示例数据。")
        return

    st.session_state["df"] = df
    with st.expander("数据预览", expanded=True):
        st.dataframe(df.head(8), width="stretch")
    st.caption("数据已就绪，请前往「② 字段设置」确认特征列与目标列。")


def _render_fields_step():
    df = st.session_state.get("df")
    if df is None:
        st.info("请先在「① 数据上传」上传数据或加载示例数据。")
        return
    st.header("② 字段设置")
    numeric_cols = [c for c in df.columns if pd.api.types.is_numeric_dtype(df[c])]
    if not numeric_cols:
        st.error("没有可用的数值列，无法建模。")
        return

    if "features" not in st.session_state or "targets" not in st.session_state:
        feat_auto, tgt_auto, excl_auto, unknown_auto = detect_columns(df)
        st.session_state["features"] = [c for c in feat_auto if c in numeric_cols]
        st.session_state["targets"] = [c for c in tgt_auto if c in numeric_cols]
        if excl_auto:
            st.caption("已自动排除：%s（编号/备注/常数/二值等）" % ", ".join(excl_auto))
        if unknown_auto:
            st.caption("未识别列（请手动指定为特征或目标）：%s" % ", ".join(unknown_auto))

    cc1, cc2 = st.columns(2)
    # 注意：不用 key 绑定 multiselect（否则切换到其他步骤页时 widget 卸载，值会被清空）。
    # 改为 default + 手动持久化到 session_state，保证跨页保留。
    features = cc1.multiselect(
        "特征列（输入，需 2 个）", options=numeric_cols,
        default=st.session_state.get("features", []),
    )
    targets = cc2.multiselect(
        "目标列（输出，需 3 个）", options=numeric_cols,
        default=st.session_state.get("targets", []),
    )
    st.session_state["features"] = list(features)
    st.session_state["targets"] = list(targets)

    if len(features) != 2 or len(targets) != 3:
        st.warning("请选择恰好 2 个特征列和 3 个目标列，再进行下一步。")
        return

    # 字段变化 → 重置 pipeline 与目标设定
    sig = (tuple(features), tuple(targets))
    if st.session_state.get("_field_sig") != sig:
        st.session_state["_field_sig"] = sig
        _reset_pipeline()
        st.session_state.pop("target_settings", None)

    st.caption("字段已确认，请前往「③ 目标设定」。")


def _render_targets_step():
    df = st.session_state.get("df")
    features = list(st.session_state.get("features", []))
    targets = list(st.session_state.get("targets", []))
    if df is None or len(features) != 2 or len(targets) != 3:
        st.info("请先完成「② 字段设置」。")
        return
    st.header("③ 目标设定")

    s = st.session_state.get("target_settings")
    if (s is None or s.get("constraint_target") not in targets
            or s.get("pareto_min_target") not in targets
            or s.get("pareto_max_target") not in targets):
        t0 = targets[0]
        s = {
            "constraint_target": t0,
            "constraint_lo": float(df[t0].quantile(0.2)),
            "constraint_hi": float(df[t0].quantile(0.8)),
            "pareto_min_target": targets[1],
            "pareto_max_target": targets[2],
        }

    c1, c2, c3 = st.columns(3)
    constraint_target = c1.selectbox(
        "硬约束目标（落在设定区间内）", targets,
        index=targets.index(s["constraint_target"]),
    )
    lo_v = c2.number_input("硬约束下限", value=float(s["constraint_lo"]))
    hi_v = c3.number_input("硬约束上限", value=float(s["constraint_hi"]))

    p1, p2 = st.columns(2)
    pareto_min_target = p1.selectbox(
        "Pareto 目标（最小化）", targets,
        index=targets.index(s["pareto_min_target"]),
    )
    pareto_max_target = p2.selectbox(
        "Pareto 目标（最大化）", targets,
        index=targets.index(s["pareto_max_target"]),
    )

    if len({constraint_target, pareto_min_target, pareto_max_target}) != 3:
        st.error("硬约束目标、最小化目标、最大化目标必须各不相同。")
        return
    if lo_v >= hi_v:
        st.error("硬约束下限必须小于上限。")
        return

    settings = {
        "constraint_target": constraint_target,
        "constraint_lo": lo_v,
        "constraint_hi": hi_v,
        "pareto_min_target": pareto_min_target,
        "pareto_max_target": pareto_max_target,
    }
    # 目标变化 → 重置 pipeline（重新优化）
    if st.session_state.get("target_settings") != settings:
        _reset_pipeline()
    st.session_state["target_settings"] = settings
    st.caption("目标已设定，请前往「④ 运行流程」点击一键运行。")


def _render_run_step():
    df = st.session_state.get("df")
    features = list(st.session_state.get("features", []))
    targets = list(st.session_state.get("targets", []))
    settings = st.session_state.get("target_settings")
    if df is None or len(features) != 2 or len(targets) != 3 or not isinstance(settings, dict):
        st.info("请先完成「② 字段设置」和「③ 目标设定」。")
        return

    st.header("④ 运行流程")
    pipe = _pipe()
    status = pipe.get("status")

    if status == "running":
        _run_poll()
    elif status == "done":
        st.success("✅ 本地计算已完成，AI 解读已在后台自动生成。")
        st.caption("可前往「⑤ 结果查看」「⑥ 反向设计」「⑦ AI 报告」查看。")
        if st.button("重新运行", key="rerun_btn"):
            _start_pipeline(df, features, targets, settings)
            st.rerun()
    elif status == "error":
        st.error("运行出错：%s" % pipe.get("error", ""))
        if st.button("重试", key="retry_btn"):
            _start_pipeline(df, features, targets, settings)
            st.rerun()
    else:
        st.info("点击下方按钮，将依次执行：数据质检 → 建模验证 → 多目标优化 → 自动 AI 解读。")
        if st.button("一键运行全流程", type="primary", key="run_btn"):
            _start_pipeline(df, features, targets, settings)
            st.rerun()


def _render_results_step():
    pipe = _pipe()
    if pipe.get("status") != "done":
        st.info("请先在「④ 运行流程」完成一键运行。")
        return

    df = st.session_state.get("df")
    results = pipe.get("model_results", {})
    qa = pipe.get("qa", {})
    settings = st.session_state.get("target_settings", {})
    features = list(st.session_state.get("features", []))
    targets = list(st.session_state.get("targets", []))

    st.header("⑤ 结果查看")
    _interpret_poll()

    # 质检
    st.subheader("📋 数据质检")
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("记录数", qa.get("n_rows", len(df)))
    c2.metric("缺失值", qa.get("missing_total", 0))
    c3.metric("重复配方行", qa.get("dup_rows", 0))
    c4.metric("唯一配方组", qa.get("n_groups", 0))
    if qa.get("anomalies"):
        st.warning("发现异常：%s" % "；".join(qa["anomalies"]))
    st.pyplot(plot_distribution(df, targets))
    _ai_block(pipe.get("qa_ai"))

    # 建模
    st.subheader("📈 建模结果（诚实交叉验证）")
    rows = []
    for t in targets:
        r = results[t]
        rows.append({
            "目标": _col_label(t),
            "最佳模型": r["best_model"],
            "嵌套CV OOF R²": round(r["oof_r2"], 4),
            "OOF MAE": round(r["oof_mae"], 4),
            "训练集 R²（仅供对比）": round(r["train_r2"], 4),
        })
    st.dataframe(pd.DataFrame(rows), width="stretch")
    st.caption("只看交叉验证 OOF R²，训练集分数不代表泛化能力。")
    st.pyplot(plot_model_comparison(results, targets))
    _ai_block(pipe.get("model_ai"))

    # 候选探索
    st.subheader("🎯 候选探索（Pareto 前沿）")
    opt = pipe.get("opt_result")
    if opt:
        candidates, pareto, lo, hi = opt
        t_c = settings["constraint_target"]
        t_p1 = settings["pareto_min_target"]
        t_p2 = settings["pareto_max_target"]
        c1, c2, c3 = st.columns(3)
        c1.metric("通过硬约束候选", len(candidates))
        c2.metric("Pareto 前沿点数", len(pareto))
        c3.metric("硬约束", "%s∈[%.1f, %.1f]" % (_col_label(t_c), settings["constraint_lo"], settings["constraint_hi"]))
        st.pyplot(plot_pareto(pareto, candidates, t_p1, t_p2))
        st.subheader("推荐候选（Pareto 前沿按 %s 升序取 6 个）" % _col_label(t_p1))
        top = pareto.sort_values(t_p1).head(6).copy()
        show_cols = []
        for f in features:
            top[_col_label(f)] = top[f].round(3)
            show_cols.append(_col_label(f))
        for t in [t_c, t_p1, t_p2]:
            top[_col_label(t)] = top[t].round(3)
            show_cols.append(_col_label(t))
        st.dataframe(top[show_cols], width="stretch", hide_index=True)
        st.caption("以上均为模型预测，不是实验验证；仅作进一步研究的方向参考。")
        _ai_block(pipe.get("opt_ai"))

    # 正向验证
    st.subheader("🔍 正向验证（输入配方预测）")
    cols = st.columns(len(features))
    vals = []
    for i, f in enumerate(features):
        v = cols[i].number_input(_col_label(f), value=float(df[f].mean()), key="fwd_%s" % f)
        vals.append(v)
    X = np.array([vals])
    fwd_rows = []
    for t in targets:
        p = float(results[t]["model"].predict(X)[0])
        fwd_rows.append({
            "目标": _col_label(t),
            "预测值": round(p, 4),
            "±误差（CV MAE）": round(results[t]["oof_mae"], 4),
            "下限": round(p - results[t]["oof_mae"], 4),
            "上限": round(p + results[t]["oof_mae"], 4),
        })
    st.dataframe(pd.DataFrame(fwd_rows), width="stretch", hide_index=True)
    st.caption("模型预测，非实验值；误差带为交叉验证 MAE。")


def _render_reverse_step():
    pipe = _pipe()
    if pipe.get("status") != "done":
        st.info("请先在「④ 运行流程」完成一键运行（需要已训练的模型）。")
        return

    df = st.session_state.get("df")
    results = pipe.get("model_results", {})
    features = list(st.session_state.get("features", []))
    targets = list(st.session_state.get("targets", []))

    st.header("⑥ 反向设计（输入性能 → 推荐原料）")
    st.caption("拖动下方滑块设定期望的目标性能值，系统在原料空间内寻找最接近的配方；修改滑块仅刷新下方推荐，不会清除已算好的结果。")

    # 每个目标一个滑块（范围 = 该目标在数据中的 min~max）
    target_vals = {}
    for t in targets:
        lo_t = float(df[t].min())
        hi_t = float(df[t].max())
        default = float(df[t].median())
        step = (hi_t - lo_t) / 200.0 if hi_t > lo_t else 0.01
        target_vals[t] = st.slider(
            "%s（期望目标值）" % _col_label(t),
            min_value=lo_t, max_value=hi_t, value=default,
            step=float(step), key="rev_%s" % t,
        )

    # 在特征网格上搜索最接近目标组合的配方
    lo = {f: float(df[f].min()) for f in features}
    hi = {f: float(df[f].max()) for f in features}
    grid = 101
    g1, g2 = np.meshgrid(
        np.linspace(lo[features[0]], hi[features[0]], grid),
        np.linspace(lo[features[1]], hi[features[1]], grid),
        indexing="ij",
    )
    X = np.column_stack([g1.ravel(), g2.ravel()])

    dist = np.zeros(X.shape[0])
    for t in targets:
        p = results[t]["model"].predict(X)
        span = max(float(df[t].max() - df[t].min()), 1e-9)
        dist += ((p - target_vals[t]) / span) ** 2
    idx = int(np.argmin(dist))
    best_x = X[idx]
    preds = {t: float(results[t]["model"].predict([best_x])[0]) for t in targets}

    # 推荐配方（材料名动态）
    st.markdown("**推荐原料配比**")
    for f, v in zip(features, best_x):
        st.markdown("- **%s**: %.3f" % (_col_label(f), v))

    st.markdown("**预测性能 vs 目标值**")
    cmp_rows = []
    for t in targets:
        cmp_rows.append({
            "目标": _col_label(t),
            "目标值": round(target_vals[t], 4),
            "预测值": round(preds[t], 4),
            "偏差": round(abs(preds[t] - target_vals[t]), 4),
        })
    st.dataframe(pd.DataFrame(cmp_rows), width="stretch", hide_index=True)
    st.caption("反向推荐为模型在原料空间内的最近邻搜索，非实验验证；仅供配方方向参考。")


def _render_report_step():
    pipe = _pipe()
    if pipe.get("status") != "done":
        st.info("请先在「④ 运行流程」完成一键运行。")
        return

    st.header("⑦ AI 报告")
    rep = pipe.get("report", {})
    status = rep.get("status")

    if status == "running":
        _report_poll()
    elif status == "done":
        text = rep.get("text")
        if text:
            st.markdown(text)
            st.download_button(
                "下载报告", text.encode("utf-8"),
                file_name="科研报告.md", mime="text/markdown",
            )
        else:
            st.info("AI 报告暂不可用（已降级），本地结果不受影响。")
    elif status == "failed":
        st.info("AI 报告生成失败，可稍后重试，本地结果不受影响。")
    else:
        st.info("报告将在本地计算完成后自动生成。")


# ---------------------------------------------------------------------------
# 主入口
# ---------------------------------------------------------------------------
def main():
    st.set_page_config(page_title="HydrogelPilot 配方设计工具", page_icon="🧪", layout="wide")

    _nav()

    current = st.session_state.get("_current_step", "data")
    st.title("🧪 水凝胶配方智能设计工具")
    st.caption("上传配方数据 → 指定特征/目标 → 一键建模与多目标优化 → AI 自动解读")

    if current == "data":
        _render_data_step()
    elif current == "fields":
        _render_fields_step()
    elif current == "targets":
        _render_targets_step()
    elif current == "run":
        _render_run_step()
    elif current == "results":
        _render_results_step()
    elif current == "reverse":
        _render_reverse_step()
    elif current == "report":
        _render_report_step()
    else:
        _render_data_step()


if __name__ == "__main__":
    main()
